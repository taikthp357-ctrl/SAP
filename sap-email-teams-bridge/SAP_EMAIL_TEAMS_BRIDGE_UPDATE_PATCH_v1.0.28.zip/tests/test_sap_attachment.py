# -*- coding: utf-8 -*-
"""Unit tests cho module MigoAttachmentRunner tự động đính kèm BBBG, VAT, Email & điền số phiếu vào HeadText."""

import tempfile
import shutil
import sys
from pathlib import Path
from unittest.mock import MagicMock
import pytest

CURRENT_DIR = Path(__file__).resolve().parent.parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from app.sap_attachment import (
    MigoAttachmentRunner,
    normalize_text,
    extract_search_tokens,
    parse_attachment_items_from_text,
    BBBG_REGEX,
    VAT_REGEX,
    MAIL_REGEX
)


@pytest.fixture
def sample_attachment_dir():
    """Tạo thư mục tạm chứa các file mẫu BBBG, VAT và Email."""
    temp_dir = tempfile.mkdtemp(prefix="test_migo_att_")
    base = Path(temp_dir)

    # Tạo các file mẫu
    (base / "in 5794_BBBG.pdf").write_text("sample content bbbg 5794")
    (base / "in 5794_VAT.pdf").write_text("sample content vat 5794")
    (base / "in 5794_Order_Mail.msg").write_text("sample outlook mail file")
    
    sub = base / "subfolder"
    sub.mkdir()
    (sub / "Thanhcong in 5799_BBGH.pdf").write_text("sample content 5799")
    (sub / "Thanhcong in 5799_HoaDon.pdf").write_text("sample content vat 5799")

    (base / "5007072362_VAT.pdf").write_text("sample vat 6157")

    yield base

    shutil.rmtree(temp_dir, ignore_errors=True)


def test_normalize_and_token_extraction():
    """Kiểm tra bóc tách token và chuẩn hóa chuỗi."""
    assert normalize_text("Thành Đạt IN- 6157") == "thanh dat in- 6157"
    nums, compact = extract_search_tokens("Thành Đạt IN- 6157")
    assert "6157" in nums
    assert "thanhdatin6157" == compact

    nums_doc, _ = extract_search_tokens("5006995954")
    assert "5006995954" in nums_doc


def test_parse_attachment_items_from_text():
    """Kiểm tra bóc tách danh sách chứng từ và số phiếu từ nội dung email / tin nhắn Teams."""
    sample_text = """
    Thư mục nguồn: \\\\10.128.10.72\\fvn$\\03.Khối sản xuất\\260802_ File ATT BBGH
    5006995954: Thành Công in 5794
    5006995985: Thành Công in 5794
    5006995500 \t Thanhcong in 5799
    5006995502 - Thành Công in - 4929
    5007072362 Thành Đạt in 6157
    """
    items = parse_attachment_items_from_text(sample_text)
    assert len(items) == 5
    assert items[0]["doc"] == "5006995954"
    assert "in 5794" in items[0]["ticket_no"]
    assert items[2]["doc"] == "5006995500"
    assert "5799" in items[2]["ticket_no"]
    assert items[4]["doc"] == "5007072362"
    assert "6157" in items[4]["ticket_no"]


def test_index_source_folder(sample_attachment_dir):
    """Kiểm tra lập chỉ mục file trong thư mục nguồn và thư mục con (bao gồm cả .msg)."""
    runner = MigoAttachmentRunner()
    index = runner.index_source_folder(str(sample_attachment_dir), recursive=True)

    assert index["total_files"] == 6  # 5 file pdf + 1 file .msg
    assert "5794" in index["token_map"]
    assert "5799" in index["token_map"]
    assert "5007072362" in index["token_map"]


def test_match_files_exact(sample_attachment_dir):
    """Kiểm tra khớp file chính xác theo số phiếu và loại file (BBBG, VAT, Mail)."""
    runner = MigoAttachmentRunner()
    index = runner.index_source_folder(str(sample_attachment_dir), recursive=True)

    # Test khớp 5794 (Có đủ BBBG, VAT, và Email .msg)
    b_path, v_path, m_path, notes = runner.match_files("5006995954", "Thành Công in 5794", index)
    assert b_path is not None
    assert "5794_BBBG.pdf" in b_path.name
    assert v_path is not None
    assert "5794_VAT.pdf" in v_path.name
    assert m_path is not None
    assert "Order_Mail.msg" in m_path.name

    # Test khớp 5799 trong thư mục con
    b_path2, v_path2, m_path2, _ = runner.match_files("5006995500", "Thanhcong in 5799", index)
    assert b_path2 is not None
    assert "5799_BBGH.pdf" in b_path2.name
    assert v_path2 is not None
    assert "5799_HoaDon.pdf" in v_path2.name
    assert m_path2 is None

    # Test thiếu file BBBG nhưng có file VAT (như case 5007072362)
    b_path3, v_path3, m_path3, notes3 = runner.match_files("5007072362", "Thành Đạt in 6157", index)
    assert b_path3 is None
    assert v_path3 is not None
    assert "5007072362_VAT.pdf" in v_path3.name
    assert "BBBG: FILE_NOT_FOUND" in notes3


def test_process_attachment_batch_dry_run(sample_attachment_dir):
    """Kiểm tra xử lý danh sách hàng loạt ở chế độ dry_run."""
    runner = MigoAttachmentRunner()
    items = [
        {"doc": "5006995954", "ticket_no": "Thành Công in 5794"},
        {"doc": "5006995500", "ticket_no": "Thanhcong in 5799"},
        {"doc": "5007072362", "ticket_no": "Thành Đạt in 6157"},
        {"doc": "9999999999", "ticket_no": "Khong Ton Tai"}
    ]

    summary = runner.process_attachment_batch(str(sample_attachment_dir), items, fill_headtext=True, dry_run=True)
    assert summary["total_items"] == 4
    assert summary["total_success"] == 3  # 3 items khớp được ít nhất 1 file
    assert summary["total_missing"] == 1  # 1 item hoàn toàn không có file

    report = runner.format_teams_report(summary)
    assert "`5006995954`: Thành Công in 5794" in report
    assert "`9999999999`: FILE_NOT_FOUND" in report
    assert "| DOC | Số phiếu | HeadText SAP | BBBG | VAT | Mail (.msg) |" in report


def test_handle_migo_headtext_mock():
    """Kiểm tra logic đọc và điền số phiếu vào Header Text trên SAP MIGO."""
    mock_session = MagicMock()
    mock_field = MagicMock()
    mock_field.Text = ""  # Ban đầu Header Text rỗng
    mock_wnd0 = MagicMock()
    mock_wnd0.findByName.return_value = mock_field
    mock_sbar = MagicMock()
    mock_sbar.MessageType = "S"
    mock_sbar.Text = "Material document changed"

    def find_by_id(path):
        if "sbar" in path:
            return mock_sbar
        elif "wnd[0]" in path:
            return mock_wnd0
        return MagicMock()

    mock_session.findById.side_effect = find_by_id

    runner = MigoAttachmentRunner()
    status, msg = runner.handle_migo_headtext(mock_session, "Thành Đạt in 6157")
    assert status == "HEADTEXT_DONE"
    assert "Đã điền và lưu mới HeadText" in msg
    assert mock_field.Text == "Thành Đạt in 6157"
    mock_wnd0.SendVKey.assert_called_with(11)  # Ctrl+S Save


def test_sap_session_gos_mock():
    """Kiểm tra tương tác mock SAP GUI với GOS."""
    mock_session = MagicMock()
    mock_sbar = MagicMock()
    mock_sbar.Text = "The attachment was successfully created"
    mock_sbar.MessageType = "S"

    mock_shell = MagicMock()
    def find_by_id(path):
        if "shell" in path:
            return mock_shell
        elif "sbar" in path:
            return mock_sbar
        return MagicMock()

    mock_session.findById.side_effect = find_by_id

    runner = MigoAttachmentRunner()
    with tempfile.NamedTemporaryFile(suffix="_VAT.pdf", delete=False) as tf:
        tf.write(b"dummy pdf")
        dummy_file = Path(tf.name)

    try:
        ok, msg = runner.attach_file_to_current_migo(mock_session, dummy_file)
        assert ok is True
        assert "DONE_SAP_ACK" in msg
        mock_shell.PressContextButton.assert_called_with("%GOS_TOOLBOX")
        mock_shell.SelectContextMenuItem.assert_called_with("%GOS_PCATTA_CREA")
    finally:
        dummy_file.unlink(missing_ok=True)


def test_process_attachment_batch_headtext_only():
    """Kiểm tra xử lý điền số phiếu HeadText khi không cung cấp thư mục đính kèm file."""
    runner = MigoAttachmentRunner()
    batch_res = runner.process_attachment_batch(
        folder_path="",
        items=[{"doc": "4995880054", "ticket_no": "OUT_P1_23581"}],
        dry_run=True
    )
    assert batch_res["total_success"] == 1
    assert batch_res["total_missing"] == 0
    res0 = batch_res["results"][0]
    assert res0["doc"] == "4995880054"
    assert res0["ticket_no"] == "OUT_P1_23581"
    assert res0["headtext_status"] == "HEADTEXT_DONE"
    assert res0["bbbg_status"] == "SKIP_NO_ATTACH"
    assert "Thành Công OUT_P1_23581" in res0["overall_status"]
