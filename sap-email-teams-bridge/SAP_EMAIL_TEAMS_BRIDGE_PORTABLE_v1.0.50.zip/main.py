# -*- coding: utf-8 -*-
"""SAP - Outlook (Mail V3) - Teams Bridge Worker.

Tính năng:
1. Nhận diện ngôn ngữ tự nhiên (Intent & Entity Recognition) từ Mail V3 của Power Automate.
2. Tự động quy đổi mã thông minh (Smart Material Resolver) qua sheet DATA trong DATA_MASTER.xlsx.
3. Tự động khởi động SAP Logon nếu chưa chạy, kết nối lại nếu bị đứt session.
4. Cơ chế Keep-Alive định kỳ chống ngắt kết nối tự động của SAP NetWeaver.
5. Gửi thông báo kết quả định dạng bảng HTML đẹp mắt về kênh Teams qua Webhook.
6. Hỗ trợ cờ --test-parser để kiểm thử bộ phân tích trực tiếp trên console.
"""

import sys
import os
import re
import time
import json
import gc
import html
from pathlib import Path
from datetime import datetime, timedelta
import pythoncom
import win32com.client

# Cho phép import các module trong app/
CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from app.config import load_config
from app.email_parser import NaturalCommandParser
from app.material_resolver import MaterialResolver
from app.teams_dispatcher import TeamsDispatcher
from app.sap_engine import SapEngine, SapExecutionError
from app.state_manager import StateManager
from app.runtime_control import WorkerLease, data_directory
from app.number_utils import set_global_sap_number_format
from app.sap_attachment import MigoAttachmentRunner
from app.bbbg_service import BbbgService
from app.nvl_service import NvlService
from app.ob_service import ObService
from app.extended_query_service import ExtendedQueryService


def run_self_test():
    """Chạy kiểm thử bộ phân tích câu lệnh từ Email V3 mà chưa cần mở Outlook/SAP."""
    resolver = MaterialResolver()

    sample_v3_mails = [
        # Mẫu 1: Email V3 bị dính dòng + có Footer quảng cáo của Microsoft Power Apps + chỉ gõ mã 8 số rút gọn
        "MSG_ID: 172966001122 SENDER_EMAIL: kho01@congty.com SENDER_NAME: Nguyễn Văn Kho "
        "RAW_TEXT: <at>Bot</at> check vị trí giúp em mã 32013765, 32024300 lô B2610 với ạ! "
        "If you want to unsubscribe from these emails, please use this form.",

        # Mẫu 2: Hỏi lịch sử xuất nhập không dấu, gõ tự nhiên
        "MSG_ID: 172966009988<br>SENDER_EMAIL: plan02@congty.com<br>SENDER_NAME: Trần Kế Hoạch<br>"
        "RAW_TEXT: @Bot xem lich su xuat nhap ma BIW73012711CA trong 14 ngay plant 3093",

        # Mẫu 3: Hỏi tồn kho ngắn gọn
        "MSG_ID: 172966005544\nSENDER_EMAIL: sx@congty.com\nSENDER_NAME: Lê Sản Xuất\n"
        "RAW_TEXT: check tồn kho 32013765 plant 3093",

        # Mẫu 4: Người dùng chỉ nhắn duy nhất mã số
        "MSG_ID: 172966007788 SENDER_EMAIL: user@congty.com SENDER_NAME: Anh Ba RAW_TEXT: 32013765 B2610"
    ]

    print("==================================================================")
    print(" CHẠY KIỂM THỬ BỘ PHÂN TÍCH Ý ĐỊNH & QUY ĐỔI MÃ VẬT TƯ (MAIL V3)")
    print("==================================================================")

    for i, mail_text in enumerate(sample_v3_mails, 1):
        parsed = NaturalCommandParser.parse_from_mail(mail_text)
        print(f"\n--- Test Case #{i} ---")
        if not parsed or not parsed.get("valid"):
            print(f"❌ Không hợp lệ: {parsed}")
            continue

        raw_mats = parsed["materials"]
        resolved_mats, notes = resolver.resolve_list(raw_mats)

        print(f"• Người gửi:     {parsed['senderName']} ({parsed['senderEmail']})")
        print(f"• Mã tin (Msg):  {parsed['messageId']}")
        print(f"• Lệnh nhận:     {parsed['command']} (Lý do: {parsed['intentReason']})")
        print(f"• Batch:         {parsed['batch'] or 'Tất cả'}")
        print(f"• Plant:         {parsed['plant']}")
        print(f"• Mã gốc nhận:   {raw_mats}")
        print(f"• Mã SAP quy đổi:{resolved_mats}")
        for note in notes:
            print(f"  └─ {note}")


def get_or_create_subfolder(parent_folder, folder_name: str):
    """Lấy hoặc tự động tạo thư mục con (Processed, Failed, v.v.)."""
    try:
        return parent_folder.Folders[folder_name]
    except Exception:
        try:
            return parent_folder.Folders.Add(folder_name)
        except Exception:
            return None


def move_mail_to_folder(mail, target_folder):
    """Chuyển mail vào thư mục chỉ định an toàn."""
    if not target_folder:
        return
    try:
        mail.Move(target_folder)
    except Exception as e:
        print(f"[OUTLOOK MOVE WARN] Không thể chuyển thư: {e}")


def move_mail_to_processed(mail, bot_folder):
    """Chuyển mail đã hoàn tất vào thư mục con Processed."""
    proc = get_or_create_subfolder(bot_folder, "Processed")
    move_mail_to_folder(mail, proc)


def move_mail_to_failed(mail, bot_folder):
    """Chuyển mail lỗi nghiệp vụ/không xử lý được vào thư mục con Failed."""
    failed = get_or_create_subfolder(bot_folder, "Failed")
    move_mail_to_folder(mail, failed)


def deliver_outbox(state_mgr, max_attempts=3):
    for item in state_mgr.get_pending_outbox(max_attempts=max_attempts):
        token = state_mgr.begin_delivery(item["req_id"])
        if token:
            outcome = TeamsDispatcher.deliver_payload(item["webhook_url"], item["payload"])
            state_mgr.finish_delivery(item["req_id"], token, outcome["status"], outcome["detail"])
            print(f"[OUTBOX] {item['req_id']} | {outcome['status']}")


def actual_sender_address(mail):
    address = str(getattr(mail, "SenderEmailAddress", "") or "").strip().lower()
    if str(getattr(mail, "SenderEmailType", "")).upper() == "EX":
        try:
            address = str(mail.Sender.GetExchangeUser().PrimarySmtpAddress).strip().lower()
        except Exception:
            return ""
    return address


def intake_subject(subject):
    return bool(re.match(r"^\s*(?:\[SAP-REQUEST\]|SAP_REQUEST)(?:\s|$|:)", str(subject), re.I))


def run_bridge():
    """Hàm chạy chính của tiến trình Worker."""
    config = load_config()

    data_dir = data_directory(config, CURRENT_DIR)
    lease = WorkerLease(data_dir).acquire()
    state_mgr = StateManager(data_dir / "bridge_state.db")
    state_mgr.recover_interrupted()
    max_retries = config.get("max_webhook_retries", 3)
    # Delivery is independent of SAP and Outlook startup.
    deliver_outbox(state_mgr, max_retries)

    webhook_url = config.get("teams_webhook_url", "")
    folder_name = config.get("outlook_folder_name", "SAP_BOT")
    poll_sec = config.get("poll_interval_seconds", 8)
    def_plant = config.get("default_plant", "3093")
    max_rows = config.get("max_alv_rows", 15000)
    keep_alive_idle = config.get("keep_alive_idle_seconds", 900)

    print("==================================================================")
    print(" SAP - OUTLOOK (MAIL V3) - TEAMS BRIDGE WORKER")
    print(" (0 OPEN PORT / 0 POWERSHELL / AUTO KEEP-ALIVE / INTENT PARSER)")
    print("==================================================================")
    print(f"• Thư mục Outlook: Inbox/{folder_name}")
    print(f"• Chu kỳ quét:     {poll_sec}s")
    print(f"• Plant mặc định:  {def_plant}")
    print(f"• Giới hạn ALV:    {max_rows} dòng")
    if "YOUR_WEBHOOK_URL_HERE" in webhook_url or not webhook_url:
        print("• Trạng thái Webhook: DRY-RUN (In payload ra terminal)")
    else:
        print("• Trạng thái Webhook: LIVE (Gửi trực tiếp lên Power Automate)")
    print("==================================================================\n")

    pythoncom.CoInitialize()

    try:
        outlook_app = win32com.client.Dispatch("Outlook.Application")
        outlook_ns = outlook_app.GetNamespace("MAPI")
        outlook = outlook_ns
        inbox = outlook_ns.GetDefaultFolder(6)  # 6 = olFolderInbox
    except Exception as e:
        raise RuntimeError(
            f"Không thể kết nối tới ứng dụng Microsoft Outlook qua COM.\n"
            f"Vui lòng đảm bảo Outlook Classic (Desktop) đang được mở trên máy!\nChi tiết: {e}"
        )

    # Tìm hoặc tự động tạo mới thư mục BOT trong Outlook
    bot_folder = None

    # 1. Quét trong Default Inbox
    try:
        for f in inbox.Folders:
            if f.Name.strip().lower() == folder_name.strip().lower():
                bot_folder = f
                print(f"[OUTLOOK] Tìm thấy thư mục '{f.Name}' trong '{inbox.Name}'.")
                break
    except Exception:
        pass

    # 2. Quét tại cấp Root của tài khoản (VD: v.taipt8@futurevn.com -> SAP_BOT)
    if bot_folder is None:
        try:
            root_store = inbox.Parent
            for f in root_store.Folders:
                if f.Name.strip().lower() == folder_name.strip().lower():
                    bot_folder = f
                    print(f"[OUTLOOK] Tìm thấy thư mục '{f.Name}' tại cấp gốc tài khoản '{root_store.Name}'.")
                    break
        except Exception:
            pass

    # 3. Quét tất cả các Store / Mailbox trong Outlook
    if bot_folder is None:
        try:
            for store in outlook_ns.Folders:
                for f in store.Folders:
                    if f.Name.strip().lower() == folder_name.strip().lower():
                        bot_folder = f
                        print(f"[OUTLOOK] Tìm thấy thư mục '{f.Name}' trong hòm thư '{store.Name}'.")
                        break
                if bot_folder:
                    break
        except Exception:
            pass

    # 4. Nếu chưa có ở bất kỳ đâu -> TỰ ĐỘNG TẠO MỚI tại gốc tài khoản hoặc trong Inbox
    if bot_folder is None:
        try:
            try:
                bot_folder = inbox.Parent.Folders.Add(folder_name)
                print(f"[OUTLOOK] Đã tự động tạo mới thư mục '{folder_name}' tại gốc tài khoản!")
            except Exception:
                bot_folder = inbox.Folders.Add(folder_name)
                print(f"[OUTLOOK] Đã tự động tạo mới thư mục '{folder_name}' trong Inbox!")
        except Exception as add_err:
            raise RuntimeError(
                f"Không tìm thấy và không thể tự động tạo thư mục '{folder_name}' trong Outlook.\n"
                f"Vui lòng tạo thư mục mang tên '{folder_name}' trong Outlook trước khi chạy!\n"
                f"Chi tiết: {add_err}"
            )

    set_global_sap_number_format(config.get("sap_number_format", "AUTO"))

    resolver = MaterialResolver()
    sap = SapEngine(
        max_alv_rows=max_rows,
        keep_alive_idle_seconds=keep_alive_idle,
        connection_index=config.get("sap_connection_index", 0),
        session_index=config.get("sap_session_index", 0),
        strict_session_safety=config.get("strict_session_safety", True),
        auto_create_session=config.get("auto_create_session", True),
        prefer_dedicated_session=config.get("prefer_dedicated_session", True),
        expected_system=config.get("sap_system", ""),
        expected_client=config.get("sap_client", ""),
        expected_user=config.get("sap_user", "")
    )
    print(f"[READY] Đang lắng nghe thư mới trong '{bot_folder.Name}'...")

    allowed_senders = [s.strip().lower() for s in config.get("allowed_senders", []) if s.strip()]
    last_sync_time = 0.0

    while not lease.should_stop():
        try:
            # Ép Outlook Classic gọi lệnh đồng bộ ngầm (Sync Send/Receive) với Server (mỗi 10s một lần, tránh nghẽn MAPI)
            now_ts = time.time()
            if now_ts - last_sync_time >= 10.0:
                try:
                    outlook.SendAndReceive(False)
                    last_sync_time = now_ts
                except Exception:
                    pass

            # Deliver durable results before touching SAP or requesting new work.
            deliver_outbox(state_mgr, max_retries)
            sap.keep_alive()

            # 3. Quét tất cả các thư trong thư mục SAP_BOT (kể cả thư đã mở xem lẫn thư chưa đọc)
            # Mọi thư đã xử lý xong đều được chuyển tự động sang thư mục con 'Processed'.
            # Do đó, bất kỳ thư nào còn nằm trong 'SAP_BOT' đều là yêu cầu đang chờ xử lý!
            folder_items = bot_folder.Items
            try:
                folder_items.Sort("[ReceivedTime]", False)  # Sắp xếp từ cũ đến mới (FIFO)
            except Exception:
                pass

            mail_candidates = []
            # 1. Quét thư mục bot_folder (SAP_BOT) - tối đa 30 thư đang chờ
            try:
                b_count = folder_items.Count
                for i in range(1, min(b_count + 1, 31)):
                    try:
                        item = folder_items.Item(i)
                        if getattr(item, "Class", 0) == 43 or hasattr(item, "Subject"):
                            mail_candidates.append(item)
                    except Exception:
                        pass
            except Exception:
                pass

            # 2. TỐC ĐỘ CAO (0ms): Dùng MAPI Restrict để nhặt ngay lập tức các thư [SAP-REQUEST] chưa đọc trong Inbox mà không nạp toàn bộ hòm thư
            if inbox and inbox != bot_folder:
                try:
                    unread_inbox = inbox.Items.Restrict('@SQL="urn:schemas:httpmail:read" = 0 AND ("urn:schemas:httpmail:subject" LIKE \'[SAP-REQUEST]%\' OR "urn:schemas:httpmail:subject" LIKE \'SAP_REQUEST%\')')
                    u_count = unread_inbox.Count
                    for i in range(1, min(u_count + 1, 31)):
                        try:
                            item = unread_inbox.Item(i)
                            subj = str(getattr(item, "Subject", "") or "")
                            if intake_subject(subj):
                                mail_candidates.append(item)
                        except Exception:
                            pass
                except Exception:
                    pass

            for mail in mail_candidates:
                if lease.should_stop():
                    break
                entry_id = getattr(mail, "EntryID", "")
                if entry_id and state_mgr.is_message_processed("", entry_id):
                    try:
                        mail.UnRead = False
                        mail.Save()
                        move_mail_to_processed(mail, bot_folder)
                    except Exception as out_err:
                        print(f"[OUTLOOK WARN] Bỏ qua lỗi cập nhật UnRead thư cũ: {out_err}")
                    continue

                req_id = StateManager.request_id(str(data_dir), "", entry_id) if entry_id else "UNIDENTIFIED"

                # Cô lập hoàn toàn lỗi từng thư để không chặn luồng
                try:
                    # 1. Kiểm tra danh sách người gửi được phép (nếu có cấu hình)
                    if allowed_senders:
                        actual_sender = actual_sender_address(mail)
                        if actual_sender not in allowed_senders:
                            print(f"[SECURITY] {req_id} | Người gửi '{actual_sender}' không thuộc allowed_senders. Chuyển thư sang Failed.")
                            try:
                                mail.UnRead = False
                                mail.Save()
                                move_mail_to_failed(mail, bot_folder)
                            except Exception as out_err:
                                print(f"[OUTLOOK WARN] Bỏ qua lỗi cập nhật UnRead thư security: {out_err}")
                            continue

                    raw_body = getattr(mail, "Body", "")
                    html_body = getattr(mail, "HTMLBody", "")
                    subject = getattr(mail, "Subject", "")

                    meta = NaturalCommandParser.parse(raw_body, html_body=html_body, subject=subject, default_plant=def_plant)

                    # LOOP GUARD: Nếu phát hiện tin nhắn Bot tự trả lời -> Bỏ qua ngay lập tức
                    if meta and meta.get("isBotEcho"):
                        print(f"[LOOP GUARD] {req_id} | Phát hiện tin nhắn phản hồi của Bot. Bỏ qua ngay lập tức để chống lặp!")
                        mail.UnRead = False
                        mail.Save()
                        move_mail_to_processed(mail, bot_folder)
                        continue

                    # Kiểm tra trùng lặp qua SQLite
                    msg_id = meta.get("messageId", "") if meta else ""
                    if msg_id and state_mgr.is_message_processed(msg_id, entry_id):
                        print(f"[DUPLICATE] {req_id} | Message ID '{msg_id}' đã xử lý thành công trước đó. Bỏ qua.")
                        mail.UnRead = False
                        mail.Save()
                        move_mail_to_processed(mail, bot_folder)
                        continue

                    if not meta or not meta.get("valid"):
                        reason = meta.get("reason", "Không rõ") if meta else "Thư rỗng hoặc không liên quan"
                        print(f"[SKIP] {req_id} | Bỏ qua yêu cầu không có mã hợp lệ: {reason}. Không gửi trợ giúp lên Teams.")
                        state_mgr.mark_message_processed(msg_id, entry_id, req_id, "SKIP", "INVALID_INPUT")
                        mail.UnRead = False
                        mail.Save()
                        move_mail_to_processed(mail, bot_folder)
                        continue

                    store_id = str(getattr(getattr(mail, "Parent", None), "StoreID", "") or data_dir)
                    req_id = StateManager.request_id(store_id, msg_id, entry_id)
                    if not state_mgr.claim_request(req_id):
                        print(f"[RECOVERY] {req_id}: kết quả đã lưu hoặc cần kiểm tra lần chạy gián đoạn; không chạy SAP lại.")
                        continue
                    cmd = meta["command"]
                    raw_mats = meta["materials"]
                    plant = meta["plant"]
                    batch = meta["batch"]
                    days = meta["days"]

                    # 3. Phân giải mã thông minh từ Sheet DATA (vd: 32013765 -> BIW32013765AA)
                    if cmd == "TON_THAP":
                        model_name = meta.get("model", "LIMO")
                        if not raw_mats:
                            resolved_mats = resolver.get_materials_by_model(model_name)
                        else:
                            resolved_mats, notes = resolver.resolve_list(raw_mats)
                        print(f"\n[DETECTED] {req_id} | Người hỏi: {meta['senderName']} ({meta['senderEmail']})")
                        print(f"  -> Ý định:   TON_THAP ({meta['intentReason']})")
                        print(f"  -> Model:    {model_name} (Xưởng: {meta.get('shop', 'BODY')})")
                        print(f"  -> Plants:   {meta.get('plants', ['3093', '3001'])} | Top={meta.get('limit', 20)}")
                        print(f"  -> Mã quét:  {len(resolved_mats)} mã tìm thấy cho model {model_name}")
                    elif cmd in ["CHECK_IB", "TIM_IB", "CHECK_PO", "TIM_GR_DOC"] and not raw_mats:
                        resolved_mats = []
                        print(f"\n[DETECTED] {req_id} | Người hỏi: {meta['senderName']} ({meta['senderEmail']})")
                        print(f"  -> Ý định:   {cmd} ({meta['intentReason']})")
                        print(f"  -> Tham số:  Inbound='{meta.get('inboundNo', '')}' | PO='{meta.get('poNo', '')}' | Ref='{meta.get('refNo', '')}' | Plant='{plant}'")
                    elif cmd not in ("PING", "WHO_IS_TAI"):
                        resolved_mats, notes = resolver.resolve_list(raw_mats)
                        print(f"\n[DETECTED] {req_id} | Người hỏi: {meta['senderName']} ({meta['senderEmail']})")
                        print(f"  -> Ý định:   {cmd} ({meta['intentReason']})")
                        print(f"  -> Mã gốc:   {raw_mats} ──> Mã SAP: {resolved_mats}")
                        print(f"  -> Tham số:  Batch='{batch or 'ALL'}' | Plant='{plant}' | Số ngày={days}")
                    else:
                        resolved_mats = []
                        print(f"\n[DETECTED] {req_id} | Lệnh PING kiểm tra kết nối từ {meta['senderName']}")

                    records = []
                    headers = {}
                    summary = ""
                    custom_html = None
                    result_status = "SUCCEEDED"

                    try:
                        if cmd == "PING":
                            custom_html = (
                                f"<div style='font-family:Segoe UI,sans-serif;background:#dafbe1;border:1px solid #4ac26b;"
                                f"border-left:4px solid #1a7f37;padding:12px 14px;border-radius:4px;color:#24292f;'>"
                                f"<div style='font-weight:bold;color:#1a7f37;font-size:14px;margin-bottom:6px;'>"
                                f"🏓 PONG! Kết nối hoàn tất thành công!</div>"
                                f"<div style='font-size:12px;line-height:1.6;'>"
                                f"• <strong>Request ID:</strong> {meta.get('requestId') or req_id}<br>"
                                f"• <strong>Thư mục lắng nghe:</strong> Outlook/{bot_folder.Name}<br>"
                                f"• <strong>Plant:</strong> {plant}<br>"
                                f"• <strong>Trạng thái SAP:</strong> Chưa kiểm tra trong lệnh PING<br>"
                                f"• <strong>Ghi chú:</strong> {meta.get('note', 'Kiểm tra đường truyền hoàn tất.')}"
                                f"</div></div>"
                            )
                            summary = f"Kiểm tra kết nối PING-PONG thành công (Request ID: {meta.get('requestId') or req_id})"

                        elif cmd == "WHO_IS_TAI":
                            custom_html = (
                                f"<div style='font-family:Segoe UI,sans-serif;background:#f0f8ff;border:1px solid #b6d4fe;"
                                f"border-left:4px solid #0969da;padding:14px 16px;border-radius:6px;color:#24292f;'>"
                                f"<div style='font-weight:bold;color:#0969da;font-size:15px;margin-bottom:8px;'>"
                                f"🦾✨ Dạ kính chào sếp! Em xin phép được giới thiệu về 'Cha đẻ' của em ạ!</div>"
                                f"<div style='font-size:13px;line-height:1.7;'>"
                                f"• <strong>Tác giả / Kiến trúc sư trưởng:</strong> Kỹ sư <strong>Phạm Tiến Tài (FVN-KSX-NMVFHP)</strong>.<br>"
                                f"• <strong>Sứ mệnh của em:</strong> Được anh Tài khai sinh, lập trình và nạp năng lượng 24/7 để đồng hành cùng các sếp và anh chị em xưởng sản xuất, "
                                f"giải phóng mọi người khỏi cảnh quay cuồng giữa rừng mã SAP, F3 mỏi tay hay trích xuất Excel thủ công!<br>"
                                f"• <strong>Năng lực cốt lõi:</strong> Soi vị trí Bin EWM (<code>/SCWM/POST</code>), kiểm tra tồn kho MB52, "
                                f"săn đơn xuất OB (<code>VL06O</code>), kiểm tra hàng về IB (<code>VL06I</code>/<code>ZMME240</code>), theo dõi STO (<code>ME2N</code>), "
                                f"tra cứu định mức BOM (<code>CS03</code>), đối soát BBBG và đính kèm MIGO GOS tự động.<br>"
                                f"• <strong>Lời nhắn từ trợ lý:</strong> Sếp cần tra cứu mã hàng, vị trí hay đơn hàng nào, cứ ra lệnh cho em nhé! "
                                f"Nếu em có điểm nào chưa chuẩn, sếp cứ 'méc' anh Tài để em được... nâng cấp thêm ạ! 😄📦"
                                f"</div></div>"
                            )
                            summary = "Giới thiệu tác giả: Kỹ sư Phạm Tiến Tài (FVN-KSX-NMVFHP) - Kiến trúc sư trưởng SAP Bridge"

                        elif cmd in ["CHECK_RES", "MB23", "MB25"]:
                            custom_html = (
                                f"<div style='font-family:Segoe UI,sans-serif;background:#fff8c5;border:1px solid #d4a72c;"
                                f"border-left:4px solid #9a6700;padding:12px 14px;border-radius:4px;color:#24292f;'>"
                                f"<div style='font-weight:bold;color:#9a6700;font-size:14px;margin-bottom:6px;'>"
                                f"📋 Kiểm tra Phiếu Lĩnh / Reservation (MB23/MB25)</div>"
                                f"<div style='font-size:12px;line-height:1.6;'>"
                                f"• <strong>Mã yêu cầu:</strong> {meta.get('requestId') or req_id}<br>"
                                f"• <strong>Trạng thái:</strong> Hệ thống đã tiếp nhận yêu cầu kiểm tra Reservation.<br>"
                                f"• <strong>Hướng dẫn:</strong> Vui lòng cung cấp số phiếu Reservation (RSNUM 10 số) để tra cứu chi tiết."
                                f"</div></div>"
                            )
                            summary = "Tra cứu thông tin phiếu lĩnh Reservation (MB23/MB25)"

                        elif cmd in ["VITRI", "VỊ TRÍ", "BIN", "POST"]:
                            records = sap.check_position_posting_change(resolved_mats, batch, plant=plant)
                            headers = {
                                "product": "Mã hàng", "batch": "Batch", "bin": "Vị trí (Bin)",
                                "totalQty": "Tổng tồn", "availQty": "Khả dụng",
                                "unit": "ĐVT", "grDate": "Ngày GR", "grTime": "Giờ GR",
                                "cat": "Trạng thái"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            summary = f"Vị trí lưu kho & Giờ GR (/SCWM/POST) cho mã: {', '.join(resolved_mats)}{mapping_info}"

                            # Smart Combo Check: Nếu /SCWM/POST trả về 0 dòng, tự động fallback kiểm tra MB52 xem còn tồn ở SLoc ngoài EWM không
                            if not records and resolved_mats:
                                try:
                                    mb52_fb = sap.check_stock_mb52(resolved_mats, plant=plant)
                                    if mb52_fb:
                                        sloc_summary = []
                                        for r_fb in mb52_fb:
                                            sloc_summary.append(f"SLoc {r_fb.get('sloc', '')}: {r_fb.get('unrest', '0')} {r_fb.get('unit', '')}")
                                        sloc_str = ", ".join(sloc_summary[:4])
                                        summary = f"Trên EWM (Kho {plant}) hiện không còn Bin nào, nhưng trên MB52 đang có tồn tại {sloc_str}!"
                                        print(f"[COMBO CHECK] EWM rỗng nhưng MB52 có tồn: {sloc_str}")
                                        for r_fb in mb52_fb:
                                            records.append({
                                                "product": r_fb.get("product", ""),
                                                "batch": r_fb.get("batch", ""),
                                                "bin": f"SLoc {r_fb.get('sloc', '')} (Ngoài EWM)",
                                                "totalQty": r_fb.get("unrest", "0"),
                                                "availQty": r_fb.get("unrest", "0"),
                                                "unit": r_fb.get("unit", ""),
                                                "grDate": "Xem MB52",
                                                "grTime": "",
                                                "cat": "Tồn SLoc"
                                            })
                                except Exception as fb_err:
                                    print(f"[COMBO CHECK WARN] Không thể fallback sang MB52: {fb_err}")

                        elif cmd in ["TON_KHO", "TONKHO"]:
                            wh_slocs = config.get("warehouse_slocs", ["1005", "3093"])
                            records = sap.check_stock_mb52(resolved_mats, plant, slocs=wh_slocs)
                            headers = {
                                "product": "Mã hàng", "plant": "Plant", "sloc": "Sloc",
                                "batch": "Batch", "unrest": "Tồn", "unit": "ĐVT"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            summary = f"Tồn kho (Kho 1005 & 3093 - Plant {plant}) cho mã: {', '.join(resolved_mats)}{mapping_info}"

                        elif cmd in ["TON", "TỒN", "MB52"]:
                            records = sap.check_stock_mb52(resolved_mats, plant)
                            headers = {
                                "product": "Mã hàng", "plant": "Plant", "sloc": "Sloc",
                                "batch": "Batch", "unrest": "Tồn", "unit": "ĐVT"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            summary = f"Tồn tổng hợp (Toàn bộ SLoc - Plant {plant}) cho mã: {', '.join(resolved_mats)}{mapping_info}"

                        elif cmd in ["LICHSU", "LỊCH SỬ", "MB51"]:
                            explicit_p = meta.get("explicitPlant", False)
                            target_plant = plant if explicit_p else ""
                            records = sap.check_history_mb51(resolved_mats, days, target_plant, explicit_plant=explicit_p)
                            headers = {
                                "product": "Mã hàng", "docNo": "Số CT", "mvtType": "Loại GD",
                                "postDate": "Ngày HT", "qty": "Số lượng", "unit": "ĐVT",
                                "sloc": "Kho", "batch": "Batch"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            plant_info = f" (Plant {plant})" if explicit_p else " (Tất cả nhà máy)"

                            is_fallback = False
                            if records:
                                cutoff_str = (datetime.now() - timedelta(days=int(days))).strftime("%Y%m%d")
                                newest_date = records[0].get("postDate", "")
                                parts = re.split(r"[./-]", newest_date)
                                if len(parts) == 3 and len(parts[2]) == 4:
                                    newest_iso = f"{parts[2]}{parts[1].zfill(2)}{parts[0].zfill(2)}"
                                    if newest_iso < cutoff_str:
                                        is_fallback = True

                            if is_fallback:
                                summary = f"Trong {days} ngày qua không có phát sinh. Đã mở rộng hiển thị {len(records)} giao dịch gần nhất (từ {records[0].get('postDate')}){plant_info} cho: {', '.join(resolved_mats)}{mapping_info}"
                            else:
                                summary = f"Lịch sử giao dịch {days} ngày (MB51){plant_info} cho mã: {', '.join(resolved_mats)}{mapping_info}"

                        elif cmd in ["IB_TREO", "IB", "INBOUND", "VL06I"]:
                            records = sap.check_inbound_treo_vl06i(resolved_mats, plant=plant)
                            headers = {
                                "ibNo": "Số IB", "refNo": "Số OB / Vận đơn", "product": "Mã hàng",
                                "batch": "Số Lô", "qty": "SL giao", "unit": "ĐVT",
                                "plant": "Plant", "sloc": "Kho nhận", "status": "Trạng thái"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            summary = f"Danh sách đơn Inbound (IB) treo chưa GR (VL06I) cho mã: {', '.join(resolved_mats)}{mapping_info}"

                        elif cmd in ["STO", "ME2N", "MB5T", "DIEUCHUYEN"]:
                            records = sap.check_sto_me2n(resolved_mats, plant=plant)
                            headers = {
                                "stoNo": "Số STO", "item": "Item", "product": "Mã hàng",
                                "orderQty": "SL Đặt", "deliveredQty": "Đã xuất", "remainingQty": "Còn nợ",
                                "unit": "ĐVT", "supplyingPlant": "Plant cấp", "receivingPlant": "Plant nhận"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            summary = f"Danh sách đơn điều chuyển STO (ME2N) cho mã: {', '.join(resolved_mats)}{mapping_info}"

                        elif cmd in ["TON_THAP", "LOW_STOCK"]:
                            model_name = meta.get("model", "LIMO")
                            shop_name = meta.get("shop", "BODY")
                            target_plants = meta.get("plants", ["3093", "3001"] if shop_name == "BODY" else ["3093", "2001", "3001"])
                            limit_cnt = meta.get("limit", 20)
                            full_model = meta.get("fullModelList", False)
                            records = sap.check_low_stock(resolved_mats, target_plants, limit=limit_cnt, model_name=model_name, shop_name=shop_name, full_model_list=full_model)
                            if shop_name == "BODY":
                                headers = {
                                    "product": "Material",
                                    "us": "US",
                                    "line_body": "Line Body",
                                    "bd_kho": "BD Kho",
                                    "bd_carset": "BD Carset",
                                    "transit": "Transit",
                                    "kho_ma": "Tồn MA",
                                    "line_ma": "Tồn Line",
                                    "model": "Model",
                                    "station": "Trạm",
                                    "status": "Cảnh báo"
                                }
                            elif shop_name == "XMD":
                                headers = {
                                    "product": "Mã hàng", "station": "Trạm", "model": "Model",
                                    "stock_3093": "Kho 3093", "stock_2001": "XMĐ 2001", "stock_3001": "Sơn 3001",
                                    "total_stock": "Tổng tồn", "unit": "ĐVT", "status": "Cảnh báo"
                                }
                            else:
                                headers = {
                                    "product": "Mã hàng", "station": "Trạm", "model": "Model",
                                    "stock_3093": "Kho FG 3093", "stock_3001": "Line Body 3001",
                                    "total_stock": "Tổng tồn", "unit": "ĐVT", "status": "Cảnh báo"
                                }
                            list_mode = "Toàn bộ danh sách" if full_model else "Ưu tiên xuất"
                            summary = f"Cảnh báo tồn kho Body - Model {model_name} ({len(records)} mã {list_mode} theo chuẩn Stock_FG_MA_BODY)"

                        elif cmd in ["CHECK_OB", "VL06O"]:
                            ob_no = meta.get("obNo", "")
                            records = sap.check_open_ob_vl06o(resolved_mats, ob_no=ob_no, plant=plant)
                            headers = {
                                "obNo": "Số OB", "product": "Mã hàng", "qty": "SL xuất", "unit": "ĐVT",
                                "sloc": "Sloc", "batch": "Batch", "shipTo": "Khách nhận", "createDate": "Ngày tạo"
                            }
                            target_label = ob_no or ', '.join(resolved_mats) or 'Tất cả'
                            summary = f"Danh sách đơn Outbound (OB) đang mở (VL06O) cho: {target_label}"

                        elif cmd in ["CHECK_BOM", "BOM", "CS03"]:
                            records = sap.check_bom_cs03(resolved_mats, plant=plant)
                            headers = {
                                "parent": "Mã cha", "component": "Mã con (BL)",
                                "description": "Tên linh kiện", "qty": "Định mức",
                                "unit": "ĐVT", "status": "Trạng thái"
                            }
                            mapping_info = f" (Quy đổi: {', '.join(raw_mats)} ➔ {', '.join(resolved_mats)})" if raw_mats != resolved_mats else ""
                            has_bom_cnt = sum(1 for r in records if str(r.get("status", "")).upper().startswith("CÓ BOM"))
                            if has_bom_cnt > 0:
                                summary = f"Kết quả kiểm tra định mức BOM (CS03) Plant {plant} cho: {', '.join(resolved_mats)}{mapping_info}"
                            else:
                                summary = f"Kết quả kiểm tra BOM cho {', '.join(resolved_mats)} tại Plant {plant}; xem trạng thái nguồn trong bảng.{mapping_info}"

                        elif cmd in ["CHECK_QUEUE", "QUEUE"]:
                            inbound_filter = meta.get("inboundNo", "") or (raw_mats[0] if raw_mats else "")
                            records = sap.check_ewm_queue_mon(inbound_filter=inbound_filter)
                            headers = {
                                "document": "Số IB / Doc", "error_message": "Nội dung lỗi Queue",
                                "queue_name": "Tên Queue"
                            }
                            filter_info = f" (Lọc theo: {inbound_filter})" if inbound_filter else ""
                            summary = f"Danh sách lỗi kẹt Queue EWM (/SCWM/MON){filter_info}"

                        elif cmd in ["LICHSU_BIN", "MON", "WHT"]:
                            bin_name = meta.get("bin", "")
                            records = sap.check_bin_history_mon(resolved_mats, bin_name=bin_name, days=days)
                            headers = {
                                "wtNo": "Số WT", "product": "Mã hàng", "batch": "Số lô",
                                "srcBin": "Bin xuất", "destBin": "Bin đích",
                                "qty": "SL chuyển", "unit": "ĐVT", "status": "Trạng thái",
                                "createDate": "Ngày tạo", "user": "Người xử lý"
                            }
                            target_label = f"Bin {bin_name}" if bin_name else f"Mã {', '.join(resolved_mats)}"
                            summary = f"Lịch sử chuyển Bin-to-Bin & Cancel WHT (/SCWM/MON) cho: {target_label}"

                        elif cmd in ["TIM_GR_DOC", "GR_DOC", "CHUNGTU_GR"]:
                            inbound_no = meta.get("inboundNo", "")
                            ref_no = meta.get("refNo", "")
                            mat_doc = meta.get("materialDocument", "")
                            records = sap.check_gr_doc_mb51(inbound_no=inbound_no, ref_no=ref_no, mat_doc=mat_doc, materials=resolved_mats, plant=plant, days=days)
                            headers = {
                                "mblnr": "Số CT GR", "mjahr": "Năm", "item": "Item", "bwart": "Loại GD",
                                "matnr": "Mã hàng", "qty": "SL", "unit": "ĐVT",
                                "xblnr": "Inbound / Ref", "postDate": "Ngày HT", "sloc": "Kho", "batch": "Số lô", "user": "Người tạo"
                            }
                            target_lbl = inbound_no or ref_no or mat_doc or (', '.join(resolved_mats) if resolved_mats else 'Tất cả')
                            summary = f"Chứng từ nhập kho GR (MB51) cho: {target_lbl}"

                        elif cmd in ["CHECK_IB", "IB_DETAIL", "KIEMTRA_IB"]:
                            inbound_no = meta.get("inboundNo", "") or (raw_mats[0] if raw_mats and raw_mats[0].startswith("18") else "")
                            expected_qty = meta.get("expectedQty", 0.0)
                            records = sap.check_inbound_detail_vl06i(inbound_no=inbound_no, materials=resolved_mats, plant=plant, expected_qty=expected_qty)
                            headers = {
                                "ibNo": "Số IB", "item": "Item", "product": "Mã hàng",
                                "actualQty": "SL Inbound", "expectedQty": "SL Yêu cầu", "delta": "Chênh lệch", "qtyCheck": "Đối chiếu SL",
                                "unit": "ĐVT", "sloc": "Kho", "status": "Trạng thái GR",
                                "refPo": "PO tham chiếu", "poItem": "PO Item"
                            }
                            summary = f"Chi tiết đơn Inbound {inbound_no or ', '.join(resolved_mats)} (VL06I Item View)"

                        elif cmd in ["TIM_IB", "FIND_IB"]:
                            po_no = meta.get("poNo", "")
                            ref_no = meta.get("refNo", "")
                            records = sap.find_inbound_vl06i(po_no=po_no, ref_no=ref_no, materials=resolved_mats, plant=plant)
                            headers = {
                                "ibNo": "Số IB", "item": "Item", "product": "Mã hàng",
                                "qty": "SL giao", "unit": "ĐVT", "sloc": "Kho",
                                "status": "Trạng thái", "refPo": "Số PO", "refNo": "Vận đơn / Bill"
                            }
                            target_lbl = po_no or ref_no or (', '.join(resolved_mats) if resolved_mats else 'Tất cả')
                            summary = f"Tìm kiếm Inbound theo tham chiếu: {target_lbl}"

                        elif cmd in ["CHECK_PO", "PO_STATUS", "KIEMTRA_PO"]:
                            po_no = meta.get("poNo", "") or (raw_mats[0] if raw_mats and raw_mats[0].startswith(("45", "55")) else "")
                            po_item = meta.get("poItem", "")
                            records = sap.check_po_me2n(po_no=po_no, materials=resolved_mats, plant=plant, po_item=po_item)
                            headers = {
                                "poNo": "Số PO", "item": "Item", "product": "Mã hàng",
                                "orderQty": "SL Đặt", "deliveredQty": "Đã nhận", "openQty": "Còn nợ",
                                "unit": "ĐVT", "plant": "Plant", "deleteInd": "Xóa/Khóa", "releaseStatus": "Duyệt"
                            }
                            summary = f"Tình trạng đơn đặt hàng PO {po_no or ', '.join(resolved_mats)} (ME2N)"

                        elif cmd in ["CHECK_FG_OB", "DIEN_OB"]:
                            records = sap.check_fg_ob_status(resolved_mats, plant=plant)
                            headers = {
                                "product": "Mã hàng", "fgStock": "Tồn FG 3093",
                                "openObList": "Đơn OB đang mở", "openObQty": "SL Đang giữ",
                                "availableQty": "Khả dụng xuất", "unit": "ĐVT",
                                "workAdvice": "Đánh giá công việc"
                            }
                            summary = f"Điều độ Thành Phẩm (FG) & Đơn OB cho: {', '.join(resolved_mats)}"

                        elif cmd in ["CHECK_NVL_MIGO", "RA_DON_MIGO", "MIGO_311", "CHECK_NVL", "CHECK_POSTING_CHANGE", "POSTING_CHANGE", "POSTING"]:
                            records = sap.check_nvl_migo_balance(resolved_mats, plant=plant or "3093", batch=batch)
                            headers = {
                                "product": "Mã hàng", "plant": "Plant", "sloc": "Kho",
                                "bin": "Vị trí Bin", "batch": "Số lô",
                                "qty": "SL Khả dụng", "unit": "ĐVT",
                                "grDate": "Ngày GR", "grTime": "Giờ GR",
                                "cat": "Trạng thái", "fifoRank": "Thứ tự FIFO",
                                "migoAdvice": "Khuyến nghị ra đơn MIGO 311"
                            }
                            summary = f"Posting Change NVL (Plant {plant or '3093'} - Kho 1005) cho: {', '.join(resolved_mats)}"

                        elif cmd in ["ATT_MIGO", "ATTACH_VAT_BBBG", "MIGO_ATT", "ATTACH_MIGO"]:
                            is_preview = meta.get("dryRun", True) is True
                            if not meta.get("explicitWriteIntent"):
                                raise ValueError("ATT_MIGO cần lệnh đính kèm/điền HeadText rõ ràng")
                            if not is_preview:
                                trusted = {str(x).strip().lower() for x in config.get("trusted_intake_senders", [])}
                                if not config.get("allow_sap_writes") or actual_sender_address(mail) not in trusted:
                                    raise ValueError("Ghi SAP chưa được bật cho nguồn thư đã xác thực; dùng dryRun để xem trước")
                                if not all(config.get(k) for k in ("sap_system", "sap_client", "sap_user")):
                                    raise ValueError("Thiếu SAP system/client/user đã cấu hình cho thao tác ghi")
                                sap.ensure_session()
                            folder_path = meta.get("folderPath", "")
                            items_to_att = meta.get("attachmentItems", [])
                            if not items_to_att:
                                att_docs = meta.get("attachmentDocs", [])
                                if not att_docs and raw_mats:
                                    att_docs = [m for m in raw_mats if m.isdigit() and len(m) >= 8]
                                items_to_att = [{"doc": d, "ticket_no": ""} for d in att_docs]

                            runner = MigoAttachmentRunner(sap_engine=sap, expected_session_identity=sap.session_identity if not is_preview else None)

                            def on_att_progress(done_count, total_count, cur_doc, cur_success):
                                try:
                                    TeamsDispatcher.send_progress_update(
                                        webhook_url, req_id, meta, done_count, total_count, cur_doc, cur_success
                                    )
                                    print(f"[PROGRESS TEAMS] {req_id} | Đã cập nhật tiến độ {done_count}/{total_count} ({int(done_count*100/total_count)}%) lên Teams!")
                                except Exception as ex:
                                    print(f"[PROGRESS WARN] Không thể gửi cập nhật tiến độ: {ex}")

                            att_summary = runner.process_attachment_batch(
                                folder_path,
                                items_to_att,
                                fill_headtext=True,
                                dry_run=is_preview,
                                year=meta.get("year"),
                                progress_callback=on_att_progress
                            )
                            records = att_summary["results"]
                            result_status = "SIMULATED" if is_preview else ("SUCCEEDED" if att_summary["total_success"] == att_summary["total_items"] else "FAILED")
                            if not folder_path:
                                headers = {
                                    "doc": "Số DOC",
                                    "ticket_no": "Số phiếu",
                                    "headtext_status": "Điền HeadText",
                                    "overall_status": "Trạng thái"
                                }
                                summary = f"Điền số phiếu HeadText MIGO ({att_summary['total_success']}/{att_summary['total_items']} thành công)"
                            else:
                                headers = {
                                    "doc": "Số DOC",
                                    "ticket_no": "Số phiếu",
                                    "headtext_status": "Điền HeadText",
                                    "bbbg_status": "BBBG",
                                    "vat_status": "VAT",
                                    "overall_status": "Trạng thái"
                                }
                                summary = f"Đính kèm VAT, BBBG & Điền HeadText MIGO ({att_summary['total_success']}/{att_summary['total_items']} thành công)"

                        elif cmd in ["TAO_BBBG", "XEM_BBBG", "BBBG_FG"]:
                            days_cnt = meta.get("days", 1)
                            mb51_rows = sap.check_history_mb51(resolved_mats, days=days_cnt, plant=plant, explicit_plant=True)
                            vl06i_rows = sap.check_inbound_treo_vl06i(resolved_mats, plant=plant)
                            recon = BbbgService.reconcile(mb51_rows, vl06i_rows, source_complete=True)
                            if cmd == "TAO_BBBG":
                                file_path = BbbgService.export_excel(recon, meta_header={"shop": meta.get("shop", "BODY")}, output_dir=data_dir / "exports" / "bbbg")
                                state_mgr.log_audit(req_id, "TAO_BBBG", "SUCCESS", target_doc=recon.get("batch_id"), user_name=meta.get("senderName"), message=f"Đã xuất file BBBG: {file_path}")
                                summary = f"Biên bản giao nhận Thành phẩm (BBBG FG) - {recon['matched_count']}/{recon['total_items']} khớp số lượng (File lưu tại máy worker: {file_path}; chưa gửi tệp lên Teams)"
                            else:
                                preview = BbbgService.generate_mail_preview(recon, shop_key=meta.get("shop", "BODY"))
                                custom_html = preview["html_preview"]
                                summary = f"Xem trước BBBG FG ({recon['matched_count']}/{recon['total_items']} khớp số lượng)"
                            records = recon.get("items", [])
                            headers = {
                                "material": "Mã hàng", "batch": "Số lô", "doc_no": "Inbound / Doc",
                                "handover_qty": "SL Bàn giao", "received_qty": "SL Nhận", "diff_qty": "Chênh lệch",
                                "gr_status": "Trạng thái", "note": "Ghi chú"
                            }

                        elif cmd in ["RA_DON_NVL", "KE_HOACH_NVL"]:
                            if meta.get("qty") is None or not meta.get("station") or not (meta.get("unit") or meta.get("uom")):
                                raise ValueError("Kế hoạch NVL cần qty, station và unit rõ ràng; không tự điền mặc định")
                            orders = [{"material": m, "qty": meta["qty"], "station": meta["station"], "unit": meta.get("unit") or meta.get("uom"), "plant": plant, "sloc": meta.get("sloc", "1005")} for m in resolved_mats]
                            stock_records = sap.check_position_posting_change(resolved_mats, batch="", plant=plant)
                            plan = NvlService.allocate_orders(orders, stock_records, source_plant=plant,
                                db_path=state_mgr.db_path, request_id=req_id, source_complete=True)
                            plan_id = plan["plan_id"]
                            result_status = "PREVIEW"
                            if config.get("allow_nvl_reservations"):
                                plan_id = NvlService.save_plan_and_reserve(plan, created_by=meta.get("senderName") or "BOT", db_path=state_mgr.db_path)
                            state_mgr.log_audit(req_id, "RA_DON_NVL", "PREVIEW", target_doc=plan_id, user_name=meta.get("senderName"), message="Kế hoạch cục bộ, chưa thực hiện MIGO trên SAP")
                            records = plan.get("allocated_items", [])
                            headers = {
                                "material": "Mã hàng", "station": "Trạm", "bin": "Bin", "batch": "Số lô",
                                "allocated_qty": "SL Phân bổ", "unit": "ĐVT", "hsd": "HSD", "gr_date": "Ngày GR"
                            }
                            summary = f"Xem trước kế hoạch NVL ({plan_id}), chưa ghi SAP: Có thể phân bổ {plan['total_allocated']}/{plan['total_ordered']}"

                        elif cmd in ["DIEU_PHOI_OB", "RC65", "XAC_NHAN_OB"]:
                            ob_no = meta.get("obNo", "")
                            ob_items = sap.check_open_ob_vl06o(resolved_mats, ob_no=ob_no, plant=plant)
                            stock_records = sap.check_position_posting_change(resolved_mats, batch="", plant=plant or "3093")
                            gate_eval = ObService.validate_whole_batch_gate(ob_no or "BATCH", ob_items, stock_records, source_complete=True)
                            result_status = "PREVIEW"
                            state_mgr.log_audit(req_id, "DIEU_PHOI_OB", "PREVIEW", target_doc=ob_no, user_name=meta.get("senderName"), message="Chỉ kiểm tra điều kiện; chưa có executor SAP đã xác minh")
                            summary = f"Xem trước Outbound {ob_no or 'Lô'}: {gate_eval['action_advice']}. Chưa điều phối hoặc xác nhận trên SAP."
                            records = gate_eval.get("items", [])
                            headers = {
                                "item_no": "Item", "material": "Mã hàng", "batch": "Số lô",
                                "required_qty": "SL Yêu cầu", "available_qty": "SL Khả dụng",
                                "deficit_qty": "Thâm hụt", "status": "Trạng thái Cổng"
                            }

                        elif cmd in ["TRA_CUU_ASN", "ASN"]:
                            inbound_no = meta.get("inboundNo", "") or (raw_mats[0] if raw_mats else "")
                            raw_asn = sap.find_inbound_vl06i(materials=resolved_mats, plant=plant, inbound_no=inbound_no)
                            asn_res = ExtendedQueryService.track_asn_provenance(inbound_no, raw_asn)
                            records = asn_res.get("items", [])
                            headers = {
                                "material": "Mã hàng", "batch": "Số lô", "qty": "SL giao",
                                "unit": "ĐVT", "po_no": "Số PO", "status": "Trạng thái"
                            }
                            summary = asn_res["summary"]

                        # Chuẩn bị payload chuẩn và đưa vào hàng đợi Outbox
                        payload, data = TeamsDispatcher.prepare_safe_payload(
                            req_id, meta, result_status, summary, records, headers, custom_html=custom_html
                        )
                        state_mgr.complete_request(msg_id, entry_id, req_id, cmd, result_status, webhook_url, payload)
                        deliver_outbox(state_mgr, max_retries)

                        try:
                            mail.UnRead = False
                            mail.Save()
                            move_mail_to_processed(mail, bot_folder)
                        except Exception as out_err:
                            print(f"[OUTLOOK WARN] Bỏ qua lỗi cập nhật UnRead sau khi hoàn tất SAP: {out_err}")

                    except Exception as sap_err:
                        print(f"[SAP ERROR] {req_id} | {sap_err}")
                        err_html = f"<p style='color:#d9534f;font-weight:bold;'>❌ Lỗi khi truy xuất SAP GUI: {html.escape(str(sap_err))}</p>"
                        fail_summary = f"Lỗi tra cứu SAP: {sap_err}"
                        fail_payload, fail_data = TeamsDispatcher.prepare_safe_payload(
                            req_id, meta, "FAILED", fail_summary, [], {}, custom_html=err_html
                        )
                        if not state_mgr.is_message_processed(msg_id, entry_id):
                            state_mgr.complete_request(msg_id, entry_id, req_id, cmd, "FAILED", webhook_url, fail_payload)
                            deliver_outbox(state_mgr, max_retries)

                        try:
                            mail.UnRead = False
                            mail.Save()
                            move_mail_to_failed(mail, bot_folder)
                        except Exception as out_err:
                            print(f"[OUTLOOK WARN] Bỏ qua lỗi cập nhật UnRead sau lỗi SAP: {out_err}")

                except Exception as mail_err:
                    print(f"[MAIL ERROR] {req_id} | Lỗi khi xử lý thư: {mail_err}")
                    try:
                        mail.UnRead = False
                        mail.Save()
                        move_mail_to_failed(mail, bot_folder)
                    except Exception:
                        pass

        except Exception as loop_err:
            print(f"[LOOP WARN] {loop_err}")

        # Tối ưu giải phóng RAM và COM object sau mỗi vòng lặp chạy nền
        try:
            import gc
            gc.collect()
            pythoncom.CoFreeUnusedLibraries()
        except Exception:
            pass

        for _ in range(max(1, int(poll_sec))):
            if lease.should_stop():
                break
            time.sleep(1)
    lease.close()
    pythoncom.CoUninitialize()


if __name__ == "__main__":
    if "--stop" in sys.argv:
        requested = WorkerLease.request_stop(data_directory(load_config(), CURRENT_DIR))
        print("Đã yêu cầu dừng sau tác vụ hiện tại." if requested else "Chưa tìm thấy worker trong thư mục dữ liệu.")
    elif "--test-parser" in sys.argv:
        run_self_test()
    else:
        run_bridge()
