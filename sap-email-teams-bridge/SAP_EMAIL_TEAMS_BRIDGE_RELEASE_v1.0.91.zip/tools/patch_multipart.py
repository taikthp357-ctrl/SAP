from pathlib import Path

# 1. Update app/teams_dispatcher.py
td_py = Path(r"G:\SAP\sap-email-teams-bridge\app\teams_dispatcher.py")
content = td_py.read_text(encoding="utf-8").replace("\r\n", "\n")

target_before_send_reply = """    @classmethod
    def send_reply("""

multipart_func = """    @classmethod
    def prepare_multipart_payloads(
        cls,
        request_id: str,
        meta: Dict[str, Any],
        status: str,
        summary: str,
        records: List[Dict[str, Any]],
        headers_map: Dict[str, str],
        custom_html: Optional[str] = None,
        chunk_size: int = 15
    ) -> List[Tuple[Dict[str, Any], bytes]]:
        \"\"\"Tự động phân tách danh sách kết quả dài (như att mail, điền số phiếu, cấp line)
        thành 2, 3 hoặc 4 tin nhắn liên tiếp khi vượt quá kích thước Teams (28 KB).\"\"\"
        if not records or len(records) <= chunk_size:
            p, d = cls.prepare_safe_payload(
                request_id, meta, status, summary, records, headers_map, custom_html=custom_html
            )
            return [(p, d)]

        total_records = len(records)
        num_parts = (total_records + chunk_size - 1) // chunk_size
        results: List[Tuple[Dict[str, Any], bytes]] = []

        for p_idx in range(num_parts):
            start = p_idx * chunk_size
            end = min(start + chunk_size, total_records)
            chunk_records = records[start:end]
            part_no = p_idx + 1

            part_req_id = f"{request_id}_p{part_no}" if num_parts > 1 else request_id
            part_summary = f"{summary} (Phần {part_no}/{num_parts})" if num_parts > 1 else summary

            part_meta = dict(meta)
            part_meta["partIndex"] = part_no
            part_meta["totalParts"] = num_parts

            sub_custom_html = None
            if custom_html and num_parts == 1:
                sub_custom_html = custom_html
            else:
                tbl_html = cls.build_html_table(chunk_records, headers_map, total_count=total_records)
                kpi_badges = cls.build_kpi_badges(records, meta.get("command", "")) if p_idx == 0 else ""

                if part_no < num_parts:
                    footer_note = (
                        f"<div style='margin-top:8px;font-family:Segoe UI,sans-serif;font-size:12px;"
                        f"color:#005a9e;font-weight:bold;background:#f0f7ff;padding:6px 10px;"
                        f"border-left:3px solid #005a9e;border-radius:3px;'>"
                        f"⏩ Dữ liệu còn tiếp ở Phần {part_no + 1}/{num_parts} bên dưới..."
                        f"</div>"
                    )
                else:
                    footer_note = (
                        f"<div style='margin-top:8px;font-family:Segoe UI,sans-serif;font-size:12px;"
                        f"color:#107c41;font-weight:bold;background:#dff6dd;padding:6px 10px;"
                        f"border-left:3px solid #107c41;border-radius:3px;'>"
                        f"✅ Đã hiển thị trọn vẹn 100% ({total_records}/{total_records} dòng)."
                        f"</div>"
                    )
                sub_custom_html = kpi_badges + tbl_html + footer_note

            p, d = cls.prepare_safe_payload(
                part_req_id, part_meta, status, part_summary, chunk_records, headers_map, custom_html=sub_custom_html
            )
            results.append((p, d))

        return results

    @classmethod
    def send_reply("""

if target_before_send_reply in content and "prepare_multipart_payloads" not in content:
    content = content.replace(target_before_send_reply, multipart_func, 1)

# Also update send_reply to support multi-part
old_send_reply_head = """        payload, data = cls.prepare_safe_payload(
            request_id, meta, status, summary, records, headers_map, custom_html
        )"""

new_send_reply_head = """        if records and len(records) > 15:
            all_parts = cls.prepare_multipart_payloads(
                request_id, meta, status, summary, records, headers_map, custom_html=custom_html, chunk_size=15
            )
            all_ok = True
            for part_payload, part_data in all_parts:
                part_size_kb = len(part_data) / 1024
                if not webhook_url or "YOUR_WEBHOOK_URL_HERE" in webhook_url:
                    print(f"[DRY-RUN] Gửi tin nhắn {part_payload['requestId']} ({part_size_kb:.1f} KB / tối đa 28 KB): {part_payload.get('summary')}")
                    continue
                req = urllib.request.Request(
                    webhook_url,
                    data=part_data,
                    headers={"Content-Type": "application/json; charset=utf-8"},
                    method="POST"
                )
                try:
                    with urllib.request.urlopen(req, timeout=15) as resp:
                        print(f"[TEAMS] Đã gửi {part_payload['requestId']} ({part_size_kb:.1f} KB - HTTP {resp.status})")
                except urllib.error.URLError as e:
                    print(f"[ERROR] Lỗi gửi Webhook Teams: {e}")
                    all_ok = False
            return all_ok

        payload, data = cls.prepare_safe_payload(
            request_id, meta, status, summary, records, headers_map, custom_html
        )"""

if old_send_reply_head in content:
    content = content.replace(old_send_reply_head, new_send_reply_head, 1)

td_py.write_text(content.replace("\n", "\r\n"), encoding="utf-8")
print("Updated teams_dispatcher.py successfully!")

# 2. Update main.py
main_py = Path(r"G:\SAP\sap-email-teams-bridge\main.py")
main_content = main_py.read_text(encoding="utf-8").replace("\r\n", "\n")

old_main_outbox = """                        # Chuẩn bị payload chuẩn và đưa vào hàng đợi Outbox
                        payload, data = TeamsDispatcher.prepare_safe_payload(
                            req_id, meta, result_status, summary, records, headers, custom_html=custom_html
                        )
                        state_mgr.complete_request(msg_id, entry_id, req_id, cmd, result_status, webhook_url, payload)
                        deliver_outbox(state_mgr, max_retries)
                        complete_mail_item(mail, bot_folder, "processed", outlook_ns=outlook)"""

new_main_outbox = """                        # Chuẩn bị payload chuẩn (hỗ trợ tự động phân tách 2, 3, 4 tin nhắn nếu danh sách dài) và đưa vào Outbox
                        multipart_payloads = TeamsDispatcher.prepare_multipart_payloads(
                            req_id, meta, result_status, summary, records, headers, custom_html=custom_html, chunk_size=15
                        )
                        for p_idx, (p_load, p_data) in enumerate(multipart_payloads):
                            p_req_id = f"{req_id}#p{p_idx+1}" if len(multipart_payloads) > 1 else req_id
                            if p_idx == 0:
                                state_mgr.complete_request(msg_id, entry_id, p_req_id, cmd, result_status, webhook_url, p_load)
                            else:
                                state_mgr.enqueue_outbox(p_req_id, webhook_url, p_load)
                        deliver_outbox(state_mgr, max_retries)
                        complete_mail_item(mail, bot_folder, "processed", outlook_ns=outlook)"""

if old_main_outbox in main_content:
    main_content = main_content.replace(old_main_outbox, new_main_outbox, 1)
    main_py.write_text(main_content.replace("\n", "\r\n"), encoding="utf-8")
    print("Updated main.py successfully!")
else:
    print("Old main outbox not found!")
