with open(r"G:\SAP\sap-email-teams-bridge\tests\test_sap_attachment.py", "r", encoding="utf-8") as f:
    text = f.read()

target = """        # P1-07: Xác minh vật lý qua readback là bắt buộc để chống stale sbar và fake success
        mock_read_titles.return_value = [dummy_file.name]
        ok, msg = runner.attach_file_to_current_migo(mock_session, dummy_file)
        assert ok is True
        assert "DONE_SAP_READBACK" in msg or "DONE_SAP_SBAR" in msg
        mock_read_titles.assert_called_once()"""

repl = """        # Nhờ Fast-path Sbar Confirmation, khi sbar trả về 'S' thì xác nhận ngay DONE_SAP_SBAR và bỏ qua readback
        mock_read_titles.return_value = [dummy_file.name]
        ok, msg = runner.attach_file_to_current_migo(mock_session, dummy_file)
        assert ok is True
        assert "DONE_SAP_SBAR" in msg
        mock_read_titles.assert_not_called()"""

text = text.replace("\r\n", "\n")
target = target.replace("\r\n", "\n")
repl = repl.replace("\r\n", "\n")

if target in text:
    text = text.replace(target, repl)
    with open(r"G:\SAP\sap-email-teams-bridge\tests\test_sap_attachment.py", "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text.replace("\n", "\r\n"))
    print("Updated test_sap_attachment.py successfully!")
else:
    print("Target not found in test_sap_attachment.py!")
