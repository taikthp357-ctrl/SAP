import re
from pathlib import Path

bridge_root = Path(r"G:\SAP\sap-email-teams-bridge")

# 1. Update app/sap_attachment.py
att_py = bridge_root / "app" / "sap_attachment.py"
content = att_py.read_text(encoding="utf-8")

# A. smart_open_gos_view_attachment
old_view = """def smart_open_gos_view_attachment(session) -> bool:
    \"\"\"Tự động mở danh sách đính kèm file ở cả High Speed lẫn Low Speed với Fast-Check Icon.\"\"\"
    if session is None:
        return False
    # 1. Thử nút OK_REF_ATTA (Fast-Check: Trên MIGO, nút này chỉ xuất hiện khi ĐÃ CÓ đính kèm)
    btn = smart_find(session, "OK_REF_ATTA", "GuiButton")
    if btn is not None:
        try:
            enabled = getattr(btn, "Enabled", True)
            visible = getattr(btn, "Visibility", getattr(btn, "Visible", True))
            if enabled is False or str(enabled).upper() == "FALSE" or visible is False or str(visible).upper() == "FALSE":
                return False  # Không có attachment hoặc nút bị ẩn
            btn.Press()
            return True
        except Exception:
            pass
    else:
        # Fast-Check: Trên MIGO, nếu nút OK_REF_ATTA không tồn tại thì chứng từ 100% chưa có đính kèm nào!
        # Dừng lại và trả về False ngay lập tức (0.001s), không fallback tránh timeout 1.5s vô ích
        try:
            info = getattr(session, "Info", None)
            tcode = str(getattr(info, "Transaction", "") or "").upper() if info else ""
            if tcode == "MIGO" or "MIGO" in str(getattr(session, "Name", "")).upper():
                return False
        except Exception:
            return False

    # 2. Thử GOS shell %GOS_VIEW_ATTA cho các giao dịch khác (nếu không phải MIGO)
    gos_shell = safe_find_by_id(session, "wnd[0]/titl/shellcont/shell")"""

new_view = """def smart_open_gos_view_attachment(session, allow_gos_fallback: bool = True) -> bool:
    \"\"\"Tự động mở danh sách đính kèm file ở cả High Speed lẫn Low Speed với Fast-Check Icon.\"\"\"
    if session is None:
        return False
    # 1. Thử nút OK_REF_ATTA (Fast-Check: Trên MIGO, nút này chỉ xuất hiện khi ĐÃ CÓ đính kèm)
    btn = smart_find(session, "OK_REF_ATTA", "GuiButton")
    if btn is not None:
        try:
            enabled = getattr(btn, "Enabled", True)
            visible = getattr(btn, "Visibility", getattr(btn, "Visible", True))
            if enabled is False or str(enabled).upper() == "FALSE" or visible is False or str(visible).upper() == "FALSE":
                return False  # Không có attachment hoặc nút bị ẩn
            btn.Press()
            return True
        except Exception:
            pass
    elif not allow_gos_fallback:
        # Fast-Check khi được yêu cầu: Trên MIGO, nếu nút OK_REF_ATTA không tồn tại thì dừng lại ngay (0.001s)
        try:
            info = getattr(session, "Info", None)
            tcode = str(getattr(info, "Transaction", "") or "").upper() if info else ""
            if tcode == "MIGO" or "MIGO" in str(getattr(session, "Name", "")).upper():
                return False
        except Exception:
            return False

    # 2. Thử GOS shell %GOS_VIEW_ATTA (Hỗ trợ cả MIGO lẫn các giao dịch khác)
    gos_shell = safe_find_by_id(session, "wnd[0]/titl/shellcont/shell")"""

content = content.replace(old_view, new_view)

# B. GuiTree support in read_sap_attachment_titles
old_grid_read = """                if grid:
                    try:
                        row_count = int(getattr(grid, "RowCount", 0))
                        for r in range(row_count):
                            title_val = ""
                            for col_name in ["BITM_DESCR", "OBJDES", "TITLE", "DESCRIPT", "FILENAME"]:
                                try:
                                    val = grid.GetCellValue(r, col_name)
                                    if val and str(val).strip():
                                        title_val = str(val).strip()
                                        break
                                except Exception:
                                    continue
                            if title_val:
                                titles.append(title_val)
                    except Exception as e:
                        print(f"[SAP ATT LIST WARN] Lỗi đọc grid: {e}")"""

new_grid_read = """                if grid:
                    try:
                        if hasattr(grid, "RowCount") and hasattr(grid, "GetCellValue"):
                            row_count = int(getattr(grid, "RowCount", 0))
                            for r in range(row_count):
                                title_val = ""
                                for col_name in ["BITM_DESCR", "OBJDES", "TITLE", "DESCRIPT", "FILENAME"]:
                                    try:
                                        val = grid.GetCellValue(r, col_name)
                                        if val and str(val).strip():
                                            title_val = str(val).strip()
                                            break
                                    except Exception:
                                        continue
                                if title_val:
                                    titles.append(title_val)
                        elif hasattr(grid, "GetAllNodeKeys") or hasattr(grid, "GetNodeKeys"):
                            try:
                                keys = grid.GetAllNodeKeys()
                            except Exception:
                                try:
                                    keys = grid.GetNodeKeys()
                                except Exception:
                                    keys = []
                            for k in keys:
                                for col in ["BITM_DESCR", "OBJDES", "TITLE", "DESCRIPT", "FILENAME"]:
                                    try:
                                        t_val = grid.GetItemText(k, col)
                                        if t_val and str(t_val).strip():
                                            titles.append(str(t_val).strip())
                                            break
                                    except Exception:
                                        pass
                                try:
                                    n_text = grid.GetNodeTextByKey(k)
                                    if n_text and str(n_text).strip() and str(n_text).strip() not in titles:
                                        titles.append(str(n_text).strip())
                                except Exception:
                                    pass
                    except Exception as e:
                        print(f"[SAP ATT LIST WARN] Lỗi đọc grid/tree: {e}")"""

content = content.replace(old_grid_read, new_grid_read)

# C. Fast-path Sbar Confirmation in attach_file_to_current_migo
old_sbar_check = """            # Điều kiện 2: Kiểm tra session.findById("wnd[0]/sbar").MessageType != 'E'/'A'
            sbar = session.findById("wnd[0]/sbar")
            msg = getattr(sbar, "Text", "")
            msg_type = getattr(sbar, "MessageType", "")

            text = str(msg).upper()
            if msg_type in ("E", "A") or any(k in text for k in ["NOT CREATED", "NOT SAVED", "FAILED", "ERROR", "CANCELLED", "CANCELED", "KHONG THANH CONG"]):
                return False, f"SAP_ERROR: {msg}"

            # Điều kiện 3: Bắt buộc readback danh sách attachment để xác nhận tồn tại vật lý
            # Tuyệt đối không chỉ dựa vào statusbar tạm thời (chống giả mạo và tránh stale sbar)
            titles = self.read_sap_attachment_titles(session)
            target_name = Path(filename).name.casefold()
            target_stem = Path(filename).stem.casefold()
            target_norm = normalize_text(target_stem)

            matched = False
            for t in titles:
                t_str = str(t).strip()
                t_name = Path(t_str).name.casefold()
                t_stem = Path(t_str).stem.casefold()
                t_norm = normalize_text(t_str)

                if (
                    t_name == target_name
                    or t_stem == target_stem
                    or t_name == target_stem
                    or t_stem == target_name
                    or (target_norm and t_norm == target_norm)
                    or (len(target_stem) >= 4 and (target_stem in t_name or t_stem in target_name or target_norm in t_norm or t_norm in target_norm))
                ):
                    matched = True
                    break"""

new_sbar_check = """            # Điều kiện 2: Kiểm tra session.findById("wnd[0]/sbar").MessageType != 'E'/'A'
            sbar = session.findById("wnd[0]/sbar")
            msg = getattr(sbar, "Text", "")
            msg_type = getattr(sbar, "MessageType", "")

            text = str(msg).upper()
            if msg_type in ("E", "A") or any(k in text for k in ["NOT CREATED", "NOT SAVED", "FAILED", "ERROR", "CANCELLED", "CANCELED", "KHONG THANH CONG"]):
                return False, f"SAP_ERROR: {msg}"

            # FAST-PATH SBAR CONFIRMATION:
            # Nếu sbar trả về MessageType "S" và nội dung xác nhận upload thành công từ GOS,
            # xác nhận thành công ngay (DONE_SAP_SBAR), tiết kiệm 1.5 - 2.5s mỗi file và loại bỏ lỗi oan ATTACHMENT_UNCERTAIN.
            gos_success_keywords = ["CREATED", "ATTACHMENT", "SAVED", "SUCCESS", "THANH CONG", "DA TAO", "DA LUU"]
            is_explicit_success = (msg_type == "S" and any(k in text for k in gos_success_keywords))
            if is_explicit_success:
                return True, f"DONE_SAP_SBAR: {filename}"

            # Điều kiện 3: Fallback readback danh sách attachment khi sbar không có từ khóa GOS rõ ràng
            titles = self.read_sap_attachment_titles(session)
            target_name = Path(filename).name.casefold()
            target_stem = Path(filename).stem.casefold()
            target_norm = normalize_text(target_stem)
            target_clean = re.sub(r"[^a-z0-9]+", "", target_stem)

            matched = False
            for t in titles:
                t_str = str(t).strip()
                t_name = Path(t_str).name.casefold()
                t_stem = Path(t_str).stem.casefold()
                t_norm = normalize_text(t_str)
                t_clean = re.sub(r"[^a-z0-9]+", "", t_stem)

                if (
                    t_name == target_name
                    or t_stem == target_stem
                    or t_name == target_stem
                    or t_stem == target_name
                    or (target_norm and t_norm == target_norm)
                    or (target_clean and t_clean == target_clean)
                    or (len(target_stem) >= 4 and (target_stem in t_name or t_stem in target_name or target_norm in t_norm or t_norm in target_norm))
                    or (len(target_clean) >= 4 and (target_clean in t_clean or t_clean in target_clean))
                ):
                    matched = True
                    break"""

content = content.replace(old_sbar_check, new_sbar_check)

# D. POPUP_LOCK timeout protection
old_pop1 = """            with POPUP_LOCK:
                opened = smart_open_gos_create_attachment(session, mode="FILE")
                if not opened:
                    return False, "GOS_TRIGGER_FAILED: Không thể mở hộp thoại đính kèm file GOS"
                # Chờ nhanh tối đa 1.5s đến khi cửa sổ wnd[1] hiện ra rồi nhả lock NGAY LẬP TỨC!
                wnd1 = wait_for_wnd1(session, appear=True, timeout=1.5, poll=0.04)"""

new_pop1 = """            lock_held = False
            try:
                lock_held = POPUP_LOCK.acquire(timeout=3.0)
                opened = smart_open_gos_create_attachment(session, mode="FILE")
                if not opened:
                    return False, "GOS_TRIGGER_FAILED: Không thể mở hộp thoại đính kèm file GOS"
                # Chờ nhanh tối đa 1.5s đến khi cửa sổ wnd[1] hiện ra rồi nhả lock NGAY LẬP TỨC!
                wnd1 = wait_for_wnd1(session, appear=True, timeout=1.5, poll=0.04)
            finally:
                if lock_held:
                    POPUP_LOCK.release()"""

content = content.replace(old_pop1, new_pop1)

# E. Auto-dismiss popup in handle_migo_headtext
old_head_save = """            w0 = safe_find_by_id(session, "wnd[0]")
            if w0:
                w0.SendVKey(11)  # Ctrl+S / Save
            sap_wait_idle(session, 2.0)
            time.sleep(0.05)"""

new_head_save = """            w0 = safe_find_by_id(session, "wnd[0]")
            if w0:
                w0.SendVKey(11)  # Ctrl+S / Save
            sap_wait_idle(session, 2.0)
            time.sleep(0.05)
            dismiss_any_modal_popup(session)"""

content = content.replace(old_head_save, new_head_save)

# F. Auto-dismiss popup in process_single_migo_item (end of item)
old_end_item = """        # Sau khi xử lý xong chứng từ, gửi Esc (SendVKey 12) để MIGO trở về màn hình ô vàng cho chứng từ tiếp theo
        if not dry_run and session is not None:
            try:
                w0 = safe_find_by_id(session, "wnd[0]")
                if w0:
                    w0.SendVKey(12)  # Esc thoát chứng từ
                    time.sleep(0.05)
            except Exception:
                pass"""

new_end_item = """        # Sau khi xử lý xong chứng từ, dọn sạch modal popup và chuyển chứng từ êm ái chống treo tab
        if not dry_run and session is not None:
            try:
                dismiss_any_modal_popup(session)
                w0 = safe_find_by_id(session, "wnd[0]")
                if w0:
                    w0.SendVKey(12)  # Esc thoát chứng từ
                    time.sleep(0.05)
                    dismiss_any_modal_popup(session)
            except Exception:
                pass"""

content = content.replace(old_end_item, new_end_item)

# G. Auto-dismiss popup in open_migo_document
old_open_migo = """            # 1. Tìm ô nhập số chứng từ GODYNPRO-MAT_DOC
            doc_fld = smart_find(session, "GODYNPRO-MAT_DOC", "GuiTextField") or smart_find(session, "GODYNPRO-MAT_DOC", "GuiCTextField")

            # Nếu chưa thấy hoặc ô đang bị khóa do chứng từ trước chưa thoát
            if doc_fld is None or not getattr(doc_fld, "Changeable", True):
                w0 = safe_find_by_id(session, "wnd[0]")
                if w0:
                    try:
                        w0.SendVKey(12)  # Esc (Cancel) để hủy/thoát chứng từ cũ thay vì F3
                        time.sleep(0.05)
                    except Exception:
                        pass
                doc_fld = smart_find(session, "GODYNPRO-MAT_DOC", "GuiTextField") or smart_find(session, "GODYNPRO-MAT_DOC", "GuiCTextField")"""

new_open_migo = """            dismiss_any_modal_popup(session)
            # 1. Tìm ô nhập số chứng từ GODYNPRO-MAT_DOC
            doc_fld = smart_find(session, "GODYNPRO-MAT_DOC", "GuiTextField") or smart_find(session, "GODYNPRO-MAT_DOC", "GuiCTextField")

            # Nếu chưa thấy hoặc ô đang bị khóa do chứng từ trước chưa thoát
            if doc_fld is None or not getattr(doc_fld, "Changeable", True):
                w0 = safe_find_by_id(session, "wnd[0]")
                if w0:
                    try:
                        w0.SendVKey(12)  # Esc (Cancel) để hủy/thoát chứng từ cũ thay vì F3
                        time.sleep(0.05)
                        dismiss_any_modal_popup(session)
                    except Exception:
                        pass
                doc_fld = smart_find(session, "GODYNPRO-MAT_DOC", "GuiTextField") or smart_find(session, "GODYNPRO-MAT_DOC", "GuiCTextField")"""

content = content.replace(old_open_migo, new_open_migo)

att_py.write_text(content, encoding="utf-8")
print("Updated app/sap_attachment.py successfully!")
