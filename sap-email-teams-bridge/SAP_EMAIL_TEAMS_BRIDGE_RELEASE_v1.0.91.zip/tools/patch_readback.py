import re
from pathlib import Path

att_py = Path(r"G:\SAP\sap-email-teams-bridge\app\sap_attachment.py")
content = att_py.read_text(encoding="utf-8")

# Replace readback / sbar logic
old_block = """            # FAST-PATH SBAR CONFIRMATION:
            # Nếu sbar trả về MessageType "S" và nội dung xác nhận upload thành công từ GOS,
            # xác nhận thành công ngay (DONE_SAP_SBAR), tiết kiệm 1.5 - 2.5s mỗi file và loại bỏ lỗi oan ATTACHMENT_UNCERTAIN.
            gos_success_keywords = ["CREATED", "ATTACHMENT", "SAVED", "SUCCESS", "THANH CONG", "DA TAO", "DA LUU"]
            is_explicit_success = (msg_type == "S" and any(k in text for k in gos_success_keywords))
            if is_explicit_success:
                return True, f"DONE_SAP_SBAR: {filename}"

            # Điều kiện 3: Fallback readback danh sách attachment khi sbar không có từ khóa GOS rõ ràng
            titles = self.read_sap_attachment_titles(session)
            target_name = Path(filename).name.casefold()
            target_stem = Path(filename).stem.casefold()
            target_norm = normalize_text(target_stem)
            target_clean = re.sub(r"[^a-z0-9]+", "", target_stem)

            matched = False
            for t in titles:
                t_str = str(t).strip()
                t_name = Path(t_str).name.casefold()
                t_stem = Path(t_str).stem.casefold()
                t_norm = normalize_text(t_str)
                t_clean = re.sub(r"[^a-z0-9]+", "", t_stem)

                if (
                    t_name == target_name
                    or t_stem == target_stem
                    or t_name == target_stem
                    or t_stem == target_name
                    or (target_norm and t_norm == target_norm)
                    or (target_clean and t_clean == target_clean)
                    or (len(target_stem) >= 4 and (target_stem in t_name or t_stem in target_name or target_norm in t_norm or t_norm in target_norm))
                    or (len(target_clean) >= 4 and (target_clean in t_clean or t_clean in target_clean))
                ):
                    matched = True
                    break

            if not matched:
                return False, f"ATTACHMENT_UNCERTAIN: Chưa đọc lại đúng tên file '{filename}' trong Attachment list trên SAP"
            return True, f"DONE_SAP_READBACK: {filename}" """

new_block = """            # Điều kiện 3: Xác minh vật lý qua readback danh sách attachment trên SAP
            titles = self.read_sap_attachment_titles(session)
            target_name = Path(filename).name.casefold()
            target_stem = Path(filename).stem.casefold()
            target_norm = normalize_text(target_stem)
            target_clean = re.sub(r"[^a-z0-9]+", "", target_stem)

            matched = False
            for t in titles:
                t_str = str(t).strip()
                t_name = Path(t_str).name.casefold()
                t_stem = Path(t_str).stem.casefold()
                t_norm = normalize_text(t_str)
                t_clean = re.sub(r"[^a-z0-9]+", "", t_stem)

                if (
                    t_name == target_name
                    or t_stem == target_stem
                    or t_name == target_stem
                    or t_stem == target_name
                    or (target_norm and t_norm == target_norm)
                    or (target_clean and t_clean == target_clean)
                    or (len(target_stem) >= 4 and (target_stem in t_name or t_stem in target_name or target_norm in t_norm or t_norm in target_norm))
                    or (len(target_clean) >= 4 and (target_clean in t_clean or t_clean in target_clean))
                ):
                    matched = True
                    break

            if matched:
                return True, f"DONE_SAP_READBACK: {filename}"

            # FAST-PATH SBAR CONFIRMATION (FALLBACK KHI READBACK CHƯA THẤY DO OK_REF_ATTA CHƯA RELOAD HOẶC GUITREE):
            # Nếu readback chưa đọc lại được (do MIGO chưa kịp vẽ lại nút OK_REF_ATTA hoặc do điều khiển Cây GuiTree),
            # nhưng thanh sbar xác nhận MessageType 'S' với từ khóa GOS thành công -> Chấp nhận DONE_SAP_SBAR!
            gos_success_keywords = ["CREATED", "ATTACHMENT", "SAVED", "SUCCESS", "THANH CONG", "DA TAO", "DA LUU"]
            is_explicit_success = (msg_type == "S" and any(k in text for k in gos_success_keywords))
            if is_explicit_success:
                return True, f"DONE_SAP_SBAR: {filename}"

            return False, f"ATTACHMENT_UNCERTAIN: Chưa đọc lại đúng tên file '{filename}' trong Attachment list trên SAP" """

content = content.replace("\r\n", "\n")
old_block = old_block.replace("\r\n", "\n").strip()
new_block = new_block.replace("\r\n", "\n").strip()

if old_block in content:
    content = content.replace(old_block, new_block)
    att_py.write_text(content.replace("\n", "\r\n"), encoding="utf-8")
    print("Successfully updated sap_attachment.py readback logic!")
else:
    print("Old block not found!")
