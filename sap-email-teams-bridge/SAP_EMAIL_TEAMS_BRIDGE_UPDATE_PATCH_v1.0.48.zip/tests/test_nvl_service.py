# -*- coding: utf-8 -*-
"""Unit tests for NvlService (Đợt 4: Ra đơn NVL V31 Zone & MIGO 311)."""

import os
from pathlib import Path
import pytest

from app.nvl_service import NvlService


@pytest.fixture
def tmp_db(tmp_path):
    db_file = tmp_path / "test_nvl.db"
    NvlService.init_tables(db_file)
    return db_file


def test_nvl_allocation_fefo_fifo(tmp_db):
    orders = [
        {"material": "BIW32013765AA", "qty": 150, "station": "OP10"}
    ]

    # Stock records with different HSD and GR Date
    stock_records = [
        # Lot 1: Far future HSD
        {"product": "BIW32013765AA", "batch": "LOT_LATE", "bin": "B-01-01", "availQty": 100, "hsd": "30/12/2026", "grDate": "01/10/2026"},
        # Lot 2: Near HSD (should be allocated FIRST by FEFO)
        {"product": "BIW32013765AA", "batch": "LOT_EARLY", "bin": "B-01-02", "availQty": 100, "hsd": "01/11/2026", "grDate": "05/10/2026"},
    ]

    plan = NvlService.allocate_orders(orders, stock_records, db_path=tmp_db)

    assert plan["total_ordered"] == 150
    assert plan["total_allocated"] == 150
    assert plan["is_full_allocation"] is True
    assert len(plan["allocated_items"]) == 2

    # Verify Lot 2 (EARLY HSD) was consumed first
    first_item = plan["allocated_items"][0]
    assert first_item["batch"] == "LOT_EARLY"
    assert first_item["allocated_qty"] == 100

    # Remaining 50 taken from Lot 1
    second_item = plan["allocated_items"][1]
    assert second_item["batch"] == "LOT_LATE"
    assert second_item["allocated_qty"] == 50


def test_nvl_stock_reservation_prevents_double_booking(tmp_db):
    orders1 = [
        {"material": "BIW32013765AA", "qty": 80, "station": "OP10"}
    ]
    stock_records = [
        {"product": "BIW32013765AA", "batch": "LOT_SINGLE", "bin": "B-01-01", "availQty": 100, "hsd": "15/12/2026", "grDate": "01/10/2026"}
    ]

    # Plan 1 allocates 80 and reserves it
    plan1 = NvlService.allocate_orders(orders1, stock_records, db_path=tmp_db)
    assert plan1["total_allocated"] == 80
    plan_id_1 = NvlService.save_plan_and_reserve(plan1, db_path=tmp_db)

    # Check active reservations
    res_map = NvlService.get_active_reservations(tmp_db)
    assert res_map[("BIW32013765AA", "LOT_SINGLE")] == 80.0

    # Plan 2 asks for 50 of the same material
    # Only 20 should be available! (100 - 80 reserved = 20)
    orders2 = [
        {"material": "BIW32013765AA", "qty": 50, "station": "OP20"}
    ]
    plan2 = NvlService.allocate_orders(orders2, stock_records, db_path=tmp_db)
    assert plan2["total_allocated"] == 20.0
    assert len(plan2["shortages"]) == 1
    assert plan2["shortages"][0]["shortage_qty"] == 30.0


def test_nvl_migo_precheck_and_execution(tmp_db):
    orders = [{"material": "BIW32013765AA", "qty": 50, "station": "OP10"}]
    stock = [{"product": "BIW32013765AA", "batch": "B01", "bin": "BIN-A", "availQty": 50}]

    plan = NvlService.allocate_orders(orders, stock, db_path=tmp_db)
    plan_id = NvlService.save_plan_and_reserve(plan, db_path=tmp_db)

    # Precheck should pass
    is_valid, hard_errors, warnings = NvlService.validate_migo_precheck(plan)
    assert is_valid is True
    assert len(hard_errors) == 0

    # Simulated execution
    exec_res = NvlService.execute_migo_311_simulated(plan_id, db_path=tmp_db)
    assert exec_res["success"] is True
    assert exec_res["material_document"].startswith("49")
    assert exec_res["status"] == "EXECUTED"

    # Verify reservation is CONSUMED
    res_map = NvlService.get_active_reservations(tmp_db)
    assert res_map.get(("BIW32013765AA", "B01"), 0.0) == 0.0
