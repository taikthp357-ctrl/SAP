# -*- coding: utf-8 -*-
"""Điều khiển SAP GUI Scripting qua COM Object trong RAM (0 PowerShell / 0 Clipboard).

Tích hợp toàn bộ mã VBS/VBA chuẩn xác từ ModuleSAP.bas & modPosting.bas của BBBG Excel:
- Điều khiển chuẩn xác các trường /SCWM/POST (Advanced Search, Owner, Multi-select, Start).
- Cơ chế _find_largest_grid quét đệ quy bắt trọn mọi ALV Grid bất kể phiên bản SAP GUI.
- Phân giải tên cột linh hoạt cả theo mã kỹ thuật (Technical ID) lẫn tiêu đề hiển thị (Caption).
- Đồng bộ tự động MB52 (kèm vị trí LGPBE) và MB51 (Lịch sử giao dịch).
"""

import os
import re
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import win32com.client

SAP_LOGON_PATH = r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe"
SAP_CONNECTION_NAME = ""


class SapEngine:
    """Quản lý kết nối và điều khiển tự động SAP GUI theo chuẩn BBBG."""

    def __init__(self, max_alv_rows: int = 300, keep_alive_idle_seconds: int = 900):
        self.max_alv_rows = max_alv_rows
        self.keep_alive_idle_seconds = keep_alive_idle_seconds
        self.session = None
        self.last_activity = time.time()
        self.ensure_session()

    def _connect_sap(self):
        """Kết nối tới phiên SAP GUI đang mở; nếu chưa chạy thì bật qua os.startfile."""
        try:
            sap_gui_auto = win32com.client.GetObject("SAPGUI")
            app = sap_gui_auto.GetScriptingEngine
        except Exception:
            if os.path.exists(SAP_LOGON_PATH):
                print("[SAP] SAP Logon chưa chạy. Đang khởi động qua os.startfile...")
                os.startfile(SAP_LOGON_PATH)
                time.sleep(5)
                sap_gui_auto = win32com.client.GetObject("SAPGUI")
                app = sap_gui_auto.GetScriptingEngine
            else:
                raise RuntimeError("SAP Logon chưa được mở trên máy trạm!")

        if app.Children.Count == 0 and SAP_CONNECTION_NAME:
            print(f"[SAP] Đang mở kết nối '{SAP_CONNECTION_NAME}'...")
            app.OpenConnection(SAP_CONNECTION_NAME, True)
            time.sleep(3)

        if app.Children.Count == 0:
            raise RuntimeError("Chưa có Connection nào trong SAP Logon. Vui lòng mở SAP và đăng nhập.")
        conn = app.Children(0)
        if conn.Children.Count == 0:
            raise RuntimeError("Chưa có Session nào đang mở trong SAP GUI.")
        session = conn.Children(0)
        self.last_activity = time.time()
        return session

    def _is_session_alive(self) -> bool:
        """Kiểm tra xem session SAP còn phản hồi trong bộ nhớ RAM hay không."""
        try:
            if self.session is None:
                return False
            _ = self.session.findById("wnd[0]").Text
            return True
        except Exception:
            return False

    def ensure_session(self):
        """Bảo đảm session luôn hợp lệ; tự động reconnect nếu phiên bị đứt."""
        if not self._is_session_alive():
            print("[SAP] Phiên SAP bị mất kết nối hoặc chưa khởi tạo, đang kết nối lại...")
            self.session = self._connect_sap()
            print("[SAP] Kết nối phiên SAP GUI thành công!")
        return self.session

    def keep_alive(self, idle_threshold_seconds: Optional[int] = None):
        """Gửi xung nhịp nhẹ làm mới phiên SAP chống timeout tự động của SAP Basis."""
        thresh = idle_threshold_seconds or self.keep_alive_idle_seconds
        if time.time() - self.last_activity < thresh:
            return

        print(f"[KEEP-ALIVE] Đã qua {int(time.time() - self.last_activity)}s không có thao tác. Gửi xung nhịp làm mới SAP...")
        try:
            if not self._is_session_alive():
                self.session = self._connect_sap()
            else:
                self.session.findById("wnd[0]/tbar[0]/okcd").Text = "/n"
                self.session.findById("wnd[0]").sendVKey(0)
                self._dismiss_popups()
            self.last_activity = time.time()
            print(f"[KEEP-ALIVE] Phiên SAP đã được làm mới an toàn ({datetime.now().strftime('%H:%M:%S')})")
        except Exception as e:
            print(f"[KEEP-ALIVE WARNING] Không thể gửi xung nhịp: {e}. Sẽ kết nối lại khi có lệnh mới.")
            try:
                self.session = self._connect_sap()
                self.last_activity = time.time()
            except Exception:
                pass

    def _wait_idle(self, timeout_sec: float = 30.0) -> bool:
        """Đợi SAP GUI hoàn tất xử lý (Busy = False) như chuẩn modSAPCore.WaitIdle."""
        t0 = time.time()
        while time.time() - t0 < timeout_sec:
            try:
                if not getattr(self.session, "Busy", False):
                    return True
            except Exception:
                return True
            time.sleep(0.1)
        return False

    def _find_by_id_safe(self, id_text: str):
        """Tìm đối tượng theo ID an toàn tuyệt đối, không ném exception nếu không thấy."""
        try:
            return self.session.findById(id_text, False)
        except Exception:
            return None

    def _get_status(self) -> Tuple[str, str]:
        """Đọc thông điệp và kiểu trạng thái từ StatusBar (wnd[0]/sbar) như modSAPCore."""
        try:
            sbar = self._find_by_id_safe("wnd[0]/sbar")
            if sbar is not None:
                txt = getattr(sbar, "Text", "")
                mtype = getattr(sbar, "MessageType", "")
                return str(txt).strip(), str(mtype).strip().upper()
        except Exception:
            pass
        return "", ""

    def _dismiss_popups(self) -> str:
        """Kiểm tra và đóng cửa sổ popup wnd[1] nếu có như modSAPCore.ClosePopups."""
        msg_text = ""
        try:
            count = 0
            while count < 10:
                wnd1 = self._find_by_id_safe("wnd[1]")
                if wnd1 is None:
                    break
                msg_text = getattr(wnd1, "Text", "")
                wnd1.sendVKey(0)
                count += 1
                self._wait_idle(3.0)
        except Exception:
            pass
        return msg_text

    def _find_largest_grid(self, max_wait_sec: float = 10.0):
        """Dò tìm ALV Grid lớn nhất trên màn hình SAP một cách đệ quy y hệt modSAPCore.FindLargestGrid."""
        start_t = time.time()
        best_grid = None
        while time.time() - start_t < max_wait_sec:
            best_grid = None
            best_rows = -1

            def _collect(obj, depth=0):
                nonlocal best_grid, best_rows
                if obj is None or depth > 14:
                    return
                try:
                    obj_type = getattr(obj, "Type", "")
                    if obj_type in ("GuiGridView", "GuiGridControl", "GuiShell"):
                        try:
                            rc = int(obj.RowCount)
                            if rc > best_rows:
                                best_rows = rc
                                best_grid = obj
                        except Exception:
                            pass
                    children = getattr(obj, "Children", None)
                    if children is not None:
                        for idx in range(children.Count):
                            _collect(children.ElementAt(idx), depth + 1)
                except Exception:
                    pass

            try:
                wnd0 = self._find_by_id_safe("wnd[0]")
                if wnd0 is not None:
                    _collect(wnd0, 0)
            except Exception:
                pass

            if best_grid is not None and best_rows > 0:
                return best_grid
            time.sleep(0.3)

        return best_grid

    def _resolve_grid_columns(self, alv_obj, column_mapping: Dict[str, List[str]]) -> Dict[str, str]:
        """Phân giải tên cột ALV Grid theo cả ID kỹ thuật lẫn Caption hiển thị như modSAPCore.ResolveColumn."""
        resolved = {}
        try:
            col_collection = alv_obj.ColumnOrder
            col_count = col_collection.Count
        except Exception:
            return resolved

        tech_cols = []
        titles = {}
        for c_idx in range(col_count):
            try:
                col_name = str(col_collection.ElementAt(c_idx)).strip()
                tech_cols.append(col_name)
                title = ""
                try:
                    title = str(alv_obj.GetColumnTitle(col_name)).strip().upper()
                except Exception:
                    try:
                        title = str(alv_obj.ColumnTitle(col_name)).strip().upper()
                    except Exception:
                        pass
                titles[col_name] = title
            except Exception:
                pass

        for out_key, candidates in column_mapping.items():
            matched_col = None
            for cand in candidates:
                cand_clean = cand.strip().upper()
                # 1. Khớp chính xác tên kỹ thuật
                for tc in tech_cols:
                    if tc.upper() == cand_clean:
                        matched_col = tc
                        break
                if matched_col:
                    break

                # 2. Khớp theo Caption / Tiêu đề cột
                for tc, title in titles.items():
                    if cand_clean in title or title in cand_clean:
                        matched_col = tc
                        break
                if matched_col:
                    break

            if matched_col:
                resolved[out_key] = matched_col

        return resolved

    def _fill_multiple_selection(self, push_button_id: str, values: List[str]):
        """Điền danh sách nhiều giá trị vào Multiple Selection mà KHÔNG đụng Clipboard."""
        clean_vals = [v.strip().upper() for v in values if v.strip()]
        if not clean_vals:
            return

        push_btn = self._find_by_id_safe(push_button_id)
        if push_btn is None:
            return
        push_btn.press()
        self._wait_idle(5.0)

        # Xóa các lựa chọn cũ nếu có nút btn[16] (Delete whole selection)
        btn16 = self._find_by_id_safe("wnd[1]/tbar[0]/btn[16]")
        if btn16 is not None:
            try:
                btn16.press()
                self._wait_idle(2.0)
            except Exception:
                pass

        tbl_id = "wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE"
        tbl = self._find_by_id_safe(tbl_id)

        for idx, val in enumerate(clean_vals):
            page_row = idx % 7
            if idx > 0 and page_row == 0 and tbl is not None:
                try:
                    tbl.verticalScrollbar.position = idx
                    page_row = 0
                except Exception:
                    pass

            cell_id = f"{tbl_id}/ctxtRSCSEL_255-SLOW_I[1,{page_row}]"
            cell = self._find_by_id_safe(cell_id)
            if cell is not None:
                try:
                    cell.text = val
                except Exception:
                    alt_cell = self._find_by_id_safe(cell_id.replace("ctxtRSCSEL_255", "txtRSCSEL_255"))
                    if alt_cell is not None:
                        alt_cell.text = val

        # Bấm Execute (F8 / btn[8]) trên popup
        btn8 = self._find_by_id_safe("wnd[1]/tbar[0]/btn[8]")
        if btn8 is not None:
            btn8.press()
        else:
            wnd1 = self._find_by_id_safe("wnd[1]")
            if wnd1 is not None:
                wnd1.sendVKey(8)

        self._wait_idle(5.0)

    def _extract_alv_grid(self, alv_obj, column_mapping: Dict[str, List[str]]) -> List[Dict[str, str]]:
        """Trích xuất ALV Grid kèm cơ chế cuộn dòng và forward-fill mã hàng như BBBG."""
        try:
            row_count = int(alv_obj.RowCount)
        except Exception:
            return []

        if row_count == 0:
            return []

        resolved_cols = self._resolve_grid_columns(alv_obj, column_mapping)
        records = []
        limit = min(row_count, self.max_alv_rows)
        last_product = ""

        for r in range(limit):
            if r % 25 == 0:
                try:
                    alv_obj.firstVisibleRow = r
                except Exception:
                    pass

            item = {}
            for out_key, sap_col in resolved_cols.items():
                try:
                    val = alv_obj.GetCellValue(r, sap_col)
                    item[out_key] = str(val).strip()
                except Exception:
                    item[out_key] = ""

            # Forward-fill Product nếu ô bị gộp hiển thị trống
            curr_prod = item.get("product", "")
            if curr_prod:
                last_product = curr_prod
            elif last_product and "product" in item:
                item["product"] = last_product

            records.append(item)

        return records

    def _open_transaction(self, tcode: str):
        """Mở Transaction trên SAP GUI an toàn tuyệt đối qua ô lệnh okcd hoặc StartTransaction."""
        self.ensure_session()
        self.last_activity = time.time()

        clean_code = tcode.strip().replace("/n", "").replace("/N", "")
        if not clean_code.startswith("/") and "/" in tcode:
            clean_code = "/" + clean_code

        okcd_command = f"/n{clean_code}"
        print(f"[SAP] Đang mở giao dịch: {okcd_command}...")

        try:
            okcd = self._find_by_id_safe("wnd[0]/tbar[0]/okcd")
            if okcd is not None:
                okcd.text = okcd_command
                self.session.findById("wnd[0]").sendVKey(0)
                self._wait_idle(5.0)
                self._dismiss_popups()
                return
        except Exception as e:
            print(f"[SAP WARN] Không thể nhập qua okcd: {e}")

        try:
            raw_tcode = clean_code
            print(f"[SAP] Thử mở bằng StartTransaction: {raw_tcode}...")
            self.session.StartTransaction(raw_tcode)
            self._wait_idle(5.0)
            self._dismiss_popups()
        except Exception as st_err:
            print(f"[SAP ERROR] Không thể mở giao dịch {tcode}: {st_err}")

    # --------------------------------------------------------------------------
    # 1. KIỂM TRA VỊ TRÍ BIN & NGÀY GIỜ GR QUA POSTING CHANGE (/SCWM/POST)
    # --------------------------------------------------------------------------
    def check_position_posting_change(
        self,
        materials: List[str],
        batch: Optional[str] = None,
        plant: str = "3093"
    ) -> List[Dict[str, str]]:
        """Tra cứu vị trí Bin, số lô, tồn khả dụng và ngày giờ GR từ /SCWM/POST theo chuẩn BBBG."""
        if not materials:
            return []

        self._open_transaction("/SCWM/POST")
        self._wait_idle(15.0)

        # 1. Các định danh ID chuẩn xác tuyệt đối từ BBBG (modPosting.bas & ModuleSAP.bas)
        ID_ADV_TOGGLE = "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/btnGV_BUTTON_TEXT"
        ID_ADV_START = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_ADVANCED_SEARCH:/SCWM/SAPLUI_POST:2300/subSUB_AS_BUTTONS:/SCMB/SAPLSERVICES:1000/btnCMD_START_ADVANCED"
        )
        ID_PRODUCT_MULTI = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_ADVANCED_SEARCH:/SCWM/SAPLUI_POST:2300/subSUB_SELECTION_SCREEN:/SCWM/SAPLUI_POST:2500/"
            "btn%_P_MATNR_%_APP_%-VALU_PUSH"
        )
        ID_PRODUCT_LOW = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_ADVANCED_SEARCH:/SCWM/SAPLUI_POST:2300/subSUB_SELECTION_SCREEN:/SCWM/SAPLUI_POST:2500/ctxtP_MATNR-LOW"
        )
        ID_OWNER_LOW = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_ADVANCED_SEARCH:/SCWM/SAPLUI_POST:2300/subSUB_SELECTION_SCREEN:/SCWM/SAPLUI_POST:2500/ctxtP_OWNER-LOW"
        )
        ID_BATCH_LOW = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_ADVANCED_SEARCH:/SCWM/SAPLUI_POST:2300/subSUB_SELECTION_SCREEN:/SCWM/SAPLUI_POST:2500/ctxtP_CHARG-LOW"
        )
        ID_STOCK_GRID = (
            "wnd[0]/usr/subSUB_COMPLETE_OIP:/SCWM/SAPLUI_POST:2000/"
            "subSUB_OIP_DATA_AREA:/SCWM/SAPLUI_POST:2210/subSUB_OIP_1_DATA:/SCWM/SAPLUI_POST:2211/"
            "cntlCONTAINER_ALV_OIP_1/shellcont/shell"
        )

        # 2. Đảm bảo Advanced Search đang mở (Nếu chưa thấy Product Low hoặc Owner Low thì bấm mở)
        owner_ctl = self._find_by_id_safe(ID_OWNER_LOW)
        prod_ctl = self._find_by_id_safe(ID_PRODUCT_LOW)
        if owner_ctl is None and prod_ctl is None:
            toggle_btn = self._find_by_id_safe(ID_ADV_TOGGLE)
            if toggle_btn is not None:
                print("[SAP POST] Bấm mở rộng bộ lọc tìm kiếm nâng cao (Advanced Search)...")
                toggle_btn.press()
                self._wait_idle(10.0)
                owner_ctl = self._find_by_id_safe(ID_OWNER_LOW)
                prod_ctl = self._find_by_id_safe(ID_PRODUCT_LOW)

        # 3. Điền Owner (mặc định 3093 như chuẩn BBBG)
        if owner_ctl is not None:
            try:
                owner_val = plant or "3093"
                owner_ctl.text = owner_val
            except Exception as e:
                print(f"[SAP POST WARN] Không thể gán Owner: {e}")

        # 4. Điền mã vật tư (Product / Material)
        clean_mats = [m.strip().upper() for m in materials if m.strip()]
        print(f"[SAP POST] Đang nhập mã hàng: {clean_mats} (Số lô: {batch or 'Tất cả'})...")

        if len(clean_mats) == 1 and prod_ctl is not None:
            prod_ctl.text = clean_mats[0]
        else:
            multi_btn = self._find_by_id_safe(ID_PRODUCT_MULTI)
            if multi_btn is not None:
                self._fill_multiple_selection(ID_PRODUCT_MULTI, clean_mats)
            elif prod_ctl is not None and clean_mats:
                prod_ctl.text = clean_mats[0]
            else:
                print("[SAP POST WARN] Không tìm thấy trường nhập mã vật tư trên /SCWM/POST!")

        # 5. Điền số lô (Batch) nếu có
        if batch:
            batch_ctl = self._find_by_id_safe(ID_BATCH_LOW)
            if batch_ctl is not None:
                try:
                    batch_ctl.text = batch.strip()
                except Exception:
                    pass

        # 6. Bấm thực thi tìm kiếm (Execute)
        print("[SAP POST] Bấm thực thi tìm kiếm (Execute)...")
        start_btn = self._find_by_id_safe(ID_ADV_START)
        if start_btn is not None:
            start_btn.press()
        else:
            self.session.findById("wnd[0]").sendVKey(8)

        self._wait_idle(25.0)
        self._dismiss_popups()

        # 7. Kiểm tra trạng thái
        status_txt, status_type = self._get_status()
        if status_type in ("E", "A"):
            print(f"[SAP POST ERROR] Trạng thái SAP báo lỗi: {status_txt}")

        # 8. Tìm ALV Grid kết quả (Ưu tiên ID chuẩn BBBG, nếu không thì dò tìm đệ quy)
        alv_grid = self._find_by_id_safe(ID_STOCK_GRID)
        if alv_grid is None:
            print("[SAP POST] ID lưới chuẩn chưa thấy, tiến hành dò tìm ALV Grid toàn màn hình...")
            alv_grid = self._find_largest_grid(max_wait_sec=10.0)

        if alv_grid is None:
            print(f"[SAP POST] Không tìm thấy ALV Grid trong /SCWM/POST. (Trạng thái SAP: '{status_txt}')")
            return []

        # 9. Trích xuất các cột với danh mục định danh tương thích tuyệt đối cả SAP ID và Caption
        col_map = {
            "product": ["MATNR", "PRODUCT", "MATERIAL", "MATNR_EXT"],
            "batch":   ["CHARG", "BATCH"],
            "bin":     ["LGPLA", "VLPLA", "NLPLA", "SOURCE STORAGE BIN", "SOURCE BIN", "STORAGE BIN", "BIN"],
            "grDate":  ["WDATU", "GR_DATE", "WEDAT", "GR DATE", "GOODS RECEIPT DATE"],
            "grTime":  ["WTIME", "GR_TIME", "UZEIT", "GR TIME", "GOODS RECEIPT TIME"],
            "qty":     ["AQUAN", "AQTY", "AVL_ALT_QTY", "AVAILABLE QTY", "AVAILABLE QUANTITY", "AVLQTY", "QUAN", "GESME"],
            "unit":    ["MEINS", "ALTME", "UNIT", "UOM"],
            "cat":     ["CAT", "TST", "STOCK TYPE", "ST", "TO_CAT"]
        }
        records = self._extract_alv_grid(alv_grid, col_map)
        print(f"[SAP POST] Đã trích xuất {len(records)} dòng từ /SCWM/POST.")

        # 10. SẮP XẾP ƯU TIÊN DỮ LIỆU GẦN NHẤT (Ngày GR & Giờ GR mới nhất lên đầu)
        def _gr_sort_key(item):
            d_raw = item.get("grDate", "")
            t_raw = item.get("grTime", "")
            parts = re.split(r"[./-]", d_raw)
            if len(parts) == 3:
                if len(parts[2]) == 4:
                    d_sort = f"{parts[2]}{parts[1].zfill(2)}{parts[0].zfill(2)}"
                else:
                    d_sort = f"{parts[0]}{parts[1].zfill(2)}{parts[2].zfill(2)}"
            else:
                d_sort = d_raw
            return (d_sort, t_raw)

        records.sort(key=_gr_sort_key, reverse=True)
        return records

    # --------------------------------------------------------------------------
    # 2. KIỂM TRA TỒN KHO TỔNG THỂ (MB52 - KÈM VỊ TRÍ BIN LGPBE THEO CHUẨN BBBG)
    # --------------------------------------------------------------------------
    def check_stock_mb52(self, materials: List[str], plant: str = "3093") -> List[Dict[str, str]]:
        """Tra cứu tồn kho tổng hợp MB52 kèm Vị trí Bin (LGPBE) theo modMB52.bas của BBBG."""
        if not materials:
            return []

        self._open_transaction("MB52")
        self._wait_idle(10.0)

        print(f"[SAP MB52] Đang nhập điều kiện tìm kiếm: Materials={materials}, Plant={plant}...")
        clean_mats = [m.strip().upper() for m in materials if m.strip()]

        mat_single = self._find_by_id_safe("wnd[0]/usr/ctxtMATNR-LOW")
        if len(clean_mats) == 1 and mat_single is not None:
            mat_single.text = clean_mats[0]
        else:
            multi_btn_id = "wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH"
            if self._find_by_id_safe(multi_btn_id) is not None:
                self._fill_multiple_selection(multi_btn_id, clean_mats)
            elif mat_single is not None and clean_mats:
                mat_single.text = clean_mats[0]

        if plant:
            for plant_field_id in ["wnd[0]/usr/ctxtWERKS-LOW", "wnd[0]/usr/ctxtRM07M-WERKS"]:
                p_ctl = self._find_by_id_safe(plant_field_id)
                if p_ctl is not None:
                    try:
                        p_ctl.text = plant
                    except Exception:
                        pass
                    break

        # Tùy chọn bỏ dòng tồn bằng 0 và định dạng dạng phẳng nếu có
        nozero_chk = self._find_by_id_safe("wnd[0]/usr/chkNOZERO")
        if nozero_chk is not None:
            try:
                nozero_chk.selected = True
            except Exception:
                pass

        flat_rad = self._find_by_id_safe("wnd[0]/usr/radPA_FLT")
        if flat_rad is not None:
            try:
                flat_rad.select()
            except Exception:
                pass

        # Điền Layout nếu có ô Layout /KHOMA như modMB52.bas
        layout_ctl = self._find_by_id_safe("wnd[0]/usr/ctxtRM07M-VARIANT")
        if layout_ctl is not None:
            try:
                layout_ctl.text = "/KHOMA"
            except Exception:
                pass

        print("[SAP MB52] Đang bấm thực thi (F8)...")
        exec_btn = self._find_by_id_safe("wnd[0]/tbar[1]/btn[8]")
        if exec_btn is not None:
            exec_btn.press()
        else:
            self.session.findById("wnd[0]").sendVKey(8)

        self._wait_idle(25.0)
        self._dismiss_popups()

        alv_grid = self._find_by_id_safe("wnd[0]/usr/cntlGRID1/shellcont/shell")
        if alv_grid is None:
            alv_grid = self._find_largest_grid(max_wait_sec=10.0)

        if alv_grid is None:
            print("[SAP MB52] Không tìm thấy bảng kết quả ALV (có thể không có dữ liệu tồn).")
            return []

        col_map = {
            "product": ["MATNR", "MATERIAL"],
            "plant":   ["WERKS", "PLANT"],
            "sloc":    ["LGORT", "SLOC", "STORAGE LOCATION"],
            "batch":   ["CHARG", "BATCH"],
            "unrest":  ["LABST", "UNRESTRICTED", "UNRESTRICTED USE"],
            "qual":    ["INSME", "QUALITY INSPECTION"],
            "bin":     ["LGPBE", "BIN", "STORAGE BIN"],
            "unit":    ["MEINS", "BASE UNIT OF MEASURE"]
        }
        records = self._extract_alv_grid(alv_grid, col_map)
        print(f"[SAP MB52] Đã trích xuất {len(records)} dòng dữ liệu tồn kho.")

        # SẮP XẾP: Ưu tiên dòng có Tồn khả dụng lớn nhất và Batch mới nhất lên đầu
        def _mb52_sort_key(item):
            qty_raw = item.get("unrest", "0").replace(".", "").replace(",", ".")
            try:
                qty = float(qty_raw)
            except Exception:
                qty = 0.0
            return (qty, item.get("batch", ""))

        records.sort(key=_mb52_sort_key, reverse=True)
        return records

    # --------------------------------------------------------------------------
    # 3. KIỂM TRA LỊCH SỬ XUẤT NHẬP (MB51)
    # --------------------------------------------------------------------------
    def check_history_mb51(self, materials: List[str], days: int = 7, plant: str = "3093") -> List[Dict[str, str]]:
        """Tra cứu lịch sử xuất nhập kho trong N ngày qua MB51."""
        if not materials:
            return []

        self._open_transaction("MB51")
        self._wait_idle(10.0)

        print(f"[SAP MB51] Đang nhập điều kiện: Materials={materials}, Days={days}, Plant={plant}...")
        clean_mats = [m.strip().upper() for m in materials if m.strip()]

        mat_single = self._find_by_id_safe("wnd[0]/usr/ctxtMATNR-LOW")
        if len(clean_mats) == 1 and mat_single is not None:
            mat_single.text = clean_mats[0]
        else:
            multi_btn_id = "wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH"
            if self._find_by_id_safe(multi_btn_id) is not None:
                self._fill_multiple_selection(multi_btn_id, clean_mats)
            elif mat_single is not None and clean_mats:
                mat_single.text = clean_mats[0]

        if plant:
            p_ctl = self._find_by_id_safe("wnd[0]/usr/ctxtWERKS-LOW")
            if p_ctl is not None:
                try:
                    p_ctl.text = plant
                except Exception:
                    pass

        end_date = datetime.now()
        start_date = end_date - timedelta(days=int(days))
        b_low = self._find_by_id_safe("wnd[0]/usr/ctxtBUDAT-LOW")
        if b_low is not None:
            b_low.text = start_date.strftime("%d.%m.%Y")
        b_high = self._find_by_id_safe("wnd[0]/usr/ctxtBUDAT-HIGH")
        if b_high is not None:
            b_high.text = end_date.strftime("%d.%m.%Y")

        print("[SAP MB51] Đang bấm thực thi (F8)...")
        exec_btn = self._find_by_id_safe("wnd[0]/tbar[1]/btn[8]")
        if exec_btn is not None:
            exec_btn.press()
        else:
            self.session.findById("wnd[0]").sendVKey(8)

        self._wait_idle(25.0)
        self._dismiss_popups()

        alv_grid = self._find_by_id_safe("wnd[0]/usr/cntlGRID1/shellcont/shell")
        if alv_grid is None:
            alv_grid = self._find_largest_grid(max_wait_sec=10.0)

        if alv_grid is None:
            print("[SAP MB51] Không tìm thấy bảng ALV lịch sử.")
            return []

        col_map = {
            "product": ["MATNR", "MATERIAL"],
            "docNo":   ["MBLNR", "MATERIAL DOCUMENT"],
            "mvtType": ["BWART", "MOVEMENT TYPE"],
            "postDate":["BUDAT", "POSTING DATE"],
            "qty":     ["MENGE", "ERFMG", "QUANTITY"],
            "unit":    ["MEINS", "ERFME", "UNIT OF ENTRY"],
            "sloc":    ["LGORT", "SLOC", "STORAGE LOCATION"],
            "batch":   ["CHARG", "BATCH"]
        }
        records = self._extract_alv_grid(alv_grid, col_map)
        print(f"[SAP MB51] Đã trích xuất {len(records)} dòng lịch sử xuất nhập.")

        # SẮP XẾP: Ngày hạch toán (Posting Date) và Số chứng từ MỚI NHẤT lên đầu
        def _mb51_sort_key(item):
            d_raw = item.get("postDate", "")
            doc = item.get("docNo", "")
            parts = re.split(r"[./-]", d_raw)
            if len(parts) == 3 and len(parts[2]) == 4:
                d_sort = f"{parts[2]}{parts[1].zfill(2)}{parts[0].zfill(2)}"
            else:
                d_sort = d_raw
            return (d_sort, doc)

        records.sort(key=_mb51_sort_key, reverse=True)
        return records
